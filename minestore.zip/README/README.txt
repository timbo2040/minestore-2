You need to have pre-setuped Nginx web-server, php7.3, MySQK database, NodeJS, Composer.
You can buy installation (webserver + website installation) for 10$.

INSTALLATION:
1. Run composer in your site directory with command: 'composer install'
2. Run NodeJS installer: 'npm i -f'
3. Give 777 rights for /storage and /storage/* files in this folder or just write command:
'chmod -R 0777 storage'
4. Set in your Nginx Website config, you can see example here: https://laravel.com/docs/7.x/deployment
Don't forget about this line: `root /example.com/public;`
5. Just open your setup and complete installation process. Don't forget to get your Discord
Guild ID in `Your Discord Server Settings -> Widgets -> Enable widget -> Guild ID`.
Find Webhook: Webhooks -> Create -> Fill all info and copy URL and put in input.

That's it!
