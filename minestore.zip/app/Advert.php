<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advert extends Model
{
    protected $fillable = [
        'title', 'content', 'button_name', 'button_url'
    ];
}
