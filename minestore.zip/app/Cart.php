<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    protected $fillable = [
        'user_id', 'items', 'price', 'is_active', 'coupon_id', 'gift_sum'
    ];

    public function coupon()
    {
        return $this->belongsTo('App\Coupon', 'coupon_id', 'id');
    }
}
