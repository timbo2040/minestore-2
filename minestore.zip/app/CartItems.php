<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CartItems extends Model
{
    protected $fillable = [
        'cart_id', 'item_id', 'count'
    ];

    public function item()
    {
        return $this->belongsTo('App\Item', 'item_id', 'id');
    }
}
