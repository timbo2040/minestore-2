<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = [
        'top_category_id', 'name', 'url', 'sorting'
    ];

    public function TopCategory()
    {
        return $this->belongsTo('App\TopCategory', 'top_category_id', 'id');
    }
}
