<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdvertController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Advert');
    }

    public function index()
    {
        $advert = \App\Http\Controllers\AdvertController::getAdvert();

        return view('admin.advert.index', compact('advert'));
    }

    public function save(Request $r)
    {
        $advert = \App\Http\Controllers\AdvertController::getAdvert();
        $advert->update($r->all());

        return redirect('/admin/advert');
    }
}
