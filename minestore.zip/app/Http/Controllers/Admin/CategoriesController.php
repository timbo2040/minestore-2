<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use App\TopCategory;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Categories');
    }

    public function index()
    {
        $categories = Category::query()->with(['TopCategory'])->orderBy('sorting')->get();

        return view('admin.categories.index', compact('categories'));
    }

    public function new()
    {
        $topCategories = TopCategory::query()->orderBy('sorting')->get();

        return view('admin.categories.new', compact('topCategories'));
    }

    public function create(Request $r)
    {
        Category::query()->create($r->all());

        return redirect('/admin/categories');
    }

    public function delete($id)
    {
        try {
            Category::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/categories');
    }

    public function category($id)
    {
        try {
            $topCategories = TopCategory::query()->orderBy('sorting')->get();
            $category = Category::query()->find($id);

            return view('admin.categories.edit', compact('category', 'topCategories'));
        } catch (\Exception $e) {
            return redirect('/admin/categories');
        }
    }

    public function edit($id, Request $r)
    {
        Category::query()->find($id)->update($r->all());

        return redirect('/admin/categories/c/'. $id);
    }
}
