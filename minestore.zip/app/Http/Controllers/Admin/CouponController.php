<?php

namespace App\Http\Controllers\Admin;

use App\Coupon;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Coupons');
    }

    public function index()
    {
        $coupons = Coupon::query()->orderBy('id')->get();

        return view('admin.coupons.index', compact('coupons'));
    }

    public function new()
    {
        return view('admin.coupons.new');
    }

    public function create(Request $r)
    {
        Coupon::query()->create($r->all());

        return redirect('/admin/coupons');
    }

    public function delete($id)
    {
        try {
            Coupon::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/coupons');
    }

    public function coupon($id)
    {
        try {
            $coupon = Coupon::query()->find($id);

            return view('admin.coupons.edit', compact('coupon'));
        } catch (\Exception $e) {
            return redirect('/admin/coupons');
        }
    }

    public function edit($id, Request $r)
    {
        Coupon::query()->find($id)->update($r->all());

        return redirect('/admin/coupons/c/'. $id);
    }
}
