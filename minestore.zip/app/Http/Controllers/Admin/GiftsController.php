<?php

namespace App\Http\Controllers\Admin;

use App\Gift;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GiftsController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Coupons');
    }

    public function index()
    {
        $gifts = Gift::query()->orderBy('id')->get();

        return view('admin.gifts.index', compact('gifts'));
    }

    public function new()
    {
        return view('admin.gifts.new');
    }

    public function create(Request $r)
    {
        Gift::query()->create($r->all());

        return redirect('/admin/gifts');
    }

    public function delete($id)
    {
        try {
            Gift::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/gifts');
    }

    public function coupon($id)
    {
        try {
            $gift = Gift::query()->find($id);

            return view('admin.gifts.edit', compact('gift'));
        } catch (\Exception $e) {
            return redirect('/admin/gifts');
        }
    }

    public function edit($id, Request $r)
    {
        Gift::query()->find($id)->update($r->all());

        return redirect('/admin/gifts/c/'. $id);
    }
}
