<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use App\Item;
use App\Server;
use App\TopCategory;
use Illuminate\Http\Request;

class GoodsController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Goods');
    }

    public function index()
    {
        $items = Item::query()->with(['server'])->orderBy('id')->get();

        return view('admin.goods.index', compact('items'));
    }

    public function new()
    {
        $topCategories = TopCategory::query()->where('url', '<>', 'NULL')->orderBy('sorting')->get();
        $categories = Category::query()->orderBy('sorting')->get();
        $servers = Server::query()->get();

        return view('admin.goods.new', compact('topCategories', 'servers', 'categories'));
    }

    public function create(Request $r)
    {
        $commands = [];

        if (isset($r->command)) {
            foreach ($r->get('command') as $command) {
                $commands[] = $command;
            }
        }

        $server_id = NULL;
        if ($r->get('server_id') !== 'NULL') {
            $server_id = $r->get('server_id');
        }

        Item::query()->create([
            'name' => $r->get('name'),
            'price' => $r->get('price'),
            'discount' => $r->get('discount'),
            'description' => $r->get('description'),
            'sorting' => $r->get('sorting'),
            'category_url' => $r->get('category_url'),
            'image' => $r->get('image'),
            'server_id' => $server_id,
            'commands' => json_encode($commands)
        ]);

        return redirect('/admin/goods');
    }

    public function delete($id)
    {
        try {
            Item::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/goods');
    }

    public function good($id)
    {
        try {
            $item = Item::query()->find($id);

            $topCategories = TopCategory::query()->where('url', '<>', 'NULL')->orderBy('sorting')->get();
            $categories = Category::query()->orderBy('sorting')->get();
            $servers = Server::query()->get();

            return view('admin.goods.edit', compact('item', 'topCategories', 'categories', 'servers'));
        } catch (\Exception $e) {
            return redirect('/admin/goods');
        }
    }

    public function edit($id, Request $r)
    {
        try {
            $item = Item::query()->find($id);

            $commands = [];

            if (isset($r->command)) {
                foreach ($r->get('command') as $command) {
                    $commands[] = $command;
                }
            }

            $server_id = NULL;
            if ($r->get('server_id') !== 'NULL') {
                $server_id = $r->get('server_id');
            }

            $item->update([
                'name' => $r->get('name'),
                'price' => $r->get('price'),
                'discount' => $r->get('discount'),
                'description' => $r->get('description'),
                'sorting' => $r->get('sorting'),
                'category_url' => $r->get('category_url'),
                'image' => $r->get('image'),
                'server_id' => $server_id,
                'commands' => json_encode($commands)
            ]);
        } catch (\Exception $e) {

        }

        return redirect('/admin/goods/c/'. $id);
    }
}
