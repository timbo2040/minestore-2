<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\Http\Controllers\Controller;
use App\Payment;
use Carbon\Carbon;

class IndexController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Dashboard');
    }

    public function index()
    {
        $users = Admin::query()->count('id');
        $paymentSuccess = Payment::query()->where('status', Payment::PAID)->count('id');
        $paymentPending = Payment::query()->where('status', Payment::PROCESSED)->count('id');
        $paymentAll = Payment::query()->count('id');
        $pays = $this->getWeeklyPayments();

        return view('admin.index.index',
            compact('users', 'paymentSuccess', 'paymentPending', 'paymentAll', 'pays'));
    }

    private function getWeeklyPayments()
    {
        $data = [];
        $thisWeek = $this->getWeek();

        switch ($thisWeek) {
            case "Monday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Tuesday'] = 0;
                $data['Wednesday'] = 0;
                $data['Thursday'] = 0;
                $data['Friday'] = 0;
                $data['Saturday'] = 0;
                $data['Sunday'] = 0;
                break;
            case "Tuesday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Wednesday'] = 0;
                $data['Thursday'] = 0;
                $data['Friday'] = 0;
                $data['Saturday'] = 0;
                $data['Sunday'] = 0;
                break;
            case "Wednesday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(2)],
                    ['created_at', '<=', Carbon::today()->subDays(2)->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Wednesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Thursday'] = 0;
                $data['Friday'] = 0;
                $data['Saturday'] = 0;
                $data['Sunday'] = 0;
                break;
            case "Thursday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(3)],
                    ['created_at', '<=', Carbon::today()->subDays(3)->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(2)],
                    ['created_at', '<=', Carbon::today()->subDays(2)->endOfDay()]])->count('id');
                $data['Wednesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Thursday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Friday'] = 0;
                $data['Saturday'] = 0;
                $data['Sunday'] = 0;
                break;
            case "Friday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(4)],
                    ['created_at', '<=', Carbon::today()->subDays(4)->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(3)],
                    ['created_at', '<=', Carbon::today()->subDays(3)->endOfDay()]])->count('id');
                $data['Wednesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(2)],
                    ['created_at', '<=', Carbon::today()->subDays(2)->endOfDay()]])->count('id');
                $data['Thursday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Friday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Saturday'] = 0;
                $data['Sunday'] = 0;
                break;
            case "Saturday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(5)],
                    ['created_at', '<=', Carbon::today()->subDays(5)->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(4)],
                    ['created_at', '<=', Carbon::today()->subDays(4)->endOfDay()]])->count('id');
                $data['Wednesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(3)],
                    ['created_at', '<=', Carbon::today()->subDays(3)->endOfDay()]])->count('id');
                $data['Thursday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(2)],
                    ['created_at', '<=', Carbon::today()->subDays(2)->endOfDay()]])->count('id');
                $data['Friday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Saturday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                $data['Sunday'] = 0;
                break;
            case "Sunday":
                $data['Monday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(6)],
                    ['created_at', '<=', Carbon::today()->subDays(6)->endOfDay()]])->count('id');
                $data['Tuesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(5)],
                    ['created_at', '<=', Carbon::today()->subDays(5)->endOfDay()]])->count('id');
                $data['Wednesday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(4)],
                    ['created_at', '<=', Carbon::today()->subDays(4)->endOfDay()]])->count('id');
                $data['Thursday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(3)],
                    ['created_at', '<=', Carbon::today()->subDays(3)->endOfDay()]])->count('id');
                $data['Friday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDays(2)],
                    ['created_at', '<=', Carbon::today()->subDays(2)->endOfDay()]])->count('id');
                $data['Saturday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()->subDay()],
                    ['created_at', '<=', Carbon::today()->subDay()->endOfDay()]])->count('id');
                $data['Sunday'] = Payment::query()->where([['status', Payment::PAID], ['created_at', '>=', Carbon::today()],
                    ['created_at', '<=', Carbon::today()->endOfDay()]])->count('id');
                break;
        }

        return $data;
    }

    private function getWeek()
    {
        $weekMap = [
            0 => 'Sunday',
            1 => 'Monday',
            2 => 'Tuesday',
            3 => 'Wednesday',
            4 => 'Thursday',
            5 => 'Friday',
            6 => 'Saturday',
        ];
        $dayOfTheWeek = Carbon::now()->dayOfWeek;
        return $weekMap[$dayOfTheWeek];
    }
}
