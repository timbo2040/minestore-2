<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Page;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Pages');
    }

    public function index()
    {
        $pages = Page::query()->orderBy('id')->get();

        return view('admin.pages.index', compact('pages'));
    }

    public function new()
    {
        return view('admin.pages.new');
    }

    public function create(Request $r)
    {
        Page::query()->create($r->all());

        return redirect('/admin/pages');
    }

    public function delete($id)
    {
        try {
            Page::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/pages');
    }

    public function page($id)
    {
        try {
            $page = Page::query()->find($id);

            return view('admin.pages.edit', compact('page'));
        } catch (\Exception $e) {
            return redirect('/admin/pages');
        }
    }

    public function edit($id, Request $r)
    {
        Page::query()->find($id)->update($r->all());

        return redirect('/admin/pages/c/'. $id);
    }
}
