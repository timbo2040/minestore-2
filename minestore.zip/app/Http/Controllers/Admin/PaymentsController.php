<?php

namespace App\Http\Controllers\Admin;

use App\CartItems;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ItemsController;
use App\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class PaymentsController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Payments');
    }

    public function index()
    {
        $payments = Payment::query()->with(['user'])->orderBy('id')->paginate(10);

        return view('admin.payments.index', compact('payments'));
    }

    public function payment($id)
    {
        try {
            $payment = Payment::query()->with(['user', 'cart'])->find($id);
            $items = CartItems::query()->with(['item'])->where('cart_id', $payment->cart_id)->get();

            return view('admin.payments.edit', compact('payment', 'items'));
        } catch (\Exception $e) {
            return redirect('/admin/payments');
        }
    }

    public function delivery($id)
    {
        try {
            $payment = Payment::query()->with(['user', 'cart'])->find($id);

            ItemsController::giveItems($payment);

            return Redirect::back();
        } catch (\Exception $e) {
            return Redirect::back();
        }
    }
}
