<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Item;
use App\Link;
use App\PaymentMethod;
use App\Server;
use App\Setting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Settings');
    }

    public function index()
    {
        $database = [
            'DB_HOST' => env('DB_HOST'),
            'DB_PORT' => env('DB_PORT'),
            'DB_DATABASE' => env('DB_DATABASE'),
            'DB_USERNAME' => env('DB_USERNAME')
        ];
        $settings = Setting::query()->find(1);

        return view('admin.settings.index', compact('database', 'settings'));
    }

    public function save(Request $r)
    {
        Setting::query()->find(1)->update([
            'site_name' => $r->get('site_name'),
            'serverIP' => $r->get('serverIP'),
            'serverPort' => $r->get('serverPort'),
            'withdraw_type' => $r->get('withdraw_type'),
            'withdraw_game' => $r->get('withdraw_game'),
            'auth' => $r->get('auth')
        ]);

        $password = env('DB_PASSWORD');

        if (strlen($r->get('DB_PASSWORD')) > 0) {
            $password = $r->get('DB_PASSWORD');
        }

        \App\Http\Controllers\SettingsController::setEnvironmentValue([
            'DB_HOST' => $r->get('DB_HOST'),
            'DB_PORT' => $r->get('DB_PORT'),
            'DB_DATABASE' => $r->get('DB_DATABASE'),
            'DB_USERNAME' => $r->get('DB_USERNAME'),
            'DB_PASSWORD' => $password
        ]);

        return redirect('/admin/settings');
    }

    public function merchant()
    {
        $payments = PaymentMethod::query()->get();
        $methods = [];

        foreach ($payments as $payment) {
            $methods[$payment->name] = [
                'enable' => $payment->enable,
                'config' => json_decode($payment->config, true)
            ];
        }

        return view('admin.settings.merchant', compact('methods'));
    }

    public function merchantSave(Request $r)
    {
        foreach ($r->all()['methods'] as $name => $method) {
            $enable = 0;
            if (isset($method['enable'])) {
                $enable = 1;
            }

            PaymentMethod::query()->where('name', $name)->update([
                'enable' => $enable,
                'config' => json_encode($method['config'])
            ]);
        }

        return redirect('/admin/settings/merchant');
    }

    public function discord()
    {
        $settings = Setting::query()->find(1);

        return view('admin.settings.discord', compact('settings'));
    }

    public function discordSave(Request $r)
    {
        Setting::query()->find(1)->update([
            'webhook_url' => $r->get('webhook_url'),
            'discord_guild_id' => $r->get('discord_guild_id'),
            'discord_url' => $r->get('discord_url')
        ]);

        return redirect('/admin/settings/discord');
    }

    public function links()
    {
        $links = Link::query()->get();

        return view('admin.settings.links', compact('links'));
    }

    public function linksSave(Request $r)
    {
        Link::query()->delete();

        if ($r->get('links')) {
            foreach ($r->get('links') as $link) {
                $type = Link::NO_SHOW;

                if (isset($link['header']) && isset($link['footer'])) {
                    $type = Link::SHOW_ALL;
                } else if (isset($link['header'])) {
                    $type = Link::SHOW_HEADER;
                } else if (isset($link['footer'])) {
                    $type = Link::SHOW_FOOTER;
                }

                Link::query()->create([
                    'name' => $link['name'],
                    'url' => $link['url'],
                    'type' => $type
                ]);
            }
        }

        return redirect('/admin/settings/links');
    }

    public function servers(Request $r)
    {
        $servers = Server::query()->get();

        return view('admin.settings.servers', compact('servers'));
    }

    public function serversSave(Request $r)
    {
        $servers = [];
        if ($r->get('servers')) {
            $servers = $r->get('servers');
        }

        foreach (Server::query()->get() as $server) {
            if (isset($servers[$server->id])) {
                $server->update($r->get('servers')[$server->id]);
                unset($servers[$server->id]);
                sort($servers);
            } else {
                $server->delete();
            }
        }

        foreach ($servers as $server) {
            Server::query()->create($server);
        }

        return redirect('/admin/settings/servers');
    }

    public function main()
    {
        $settings = Setting::query()->find(1);
        $items = Item::query()->get();

        return view('admin.settings.main', compact('settings', 'items'));
    }

    public function mainSave(Request $r)
    {
        $goal = $r->get('index_goal');
        $settings = Setting::query()->find(1);

        if ($settings->index_goal !== $goal) {
            $settings->update([
                'index_goal_sum' => 0
            ]);
        }

        Setting::query()->find(1)->update($r->all());

        return redirect('/admin/settings/main');
    }
}
