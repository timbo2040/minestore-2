<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\TopCategory;
use Illuminate\Http\Request;

class TopCategoriesController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Top categories');
    }

    public function index()
    {
        $topCategories = TopCategory::query()->orderBy('sorting')->get();

        return view('admin.top_categories.index', compact('topCategories'));
    }

    public function new()
    {
        return view('admin.top_categories.new');
    }

    public function create(Request $r)
    {
        TopCategory::query()->create($r->all());

        return redirect('/admin/top_categories');
    }

    public function delete($id)
    {
        try {
            TopCategory::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/top_categories');
    }

    public function category($id)
    {
        try {
            $category = TopCategory::query()->find($id);

            return view('admin.top_categories.edit', compact('category'));
        } catch (\Exception $e) {
            return redirect('/admin/top_categories');
        }
    }

    public function edit($id, Request $r)
    {
        TopCategory::query()->find($id)->update($r->all());

        return redirect('/admin/top_categories/c/'. $id);
    }
}
