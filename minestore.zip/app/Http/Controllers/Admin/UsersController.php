<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function __construct()
    {
        $this->setTitle('Users');
    }

    public function index()
    {
        $users = Admin::query()->orderBy('id')->get();

        return view('admin.users.index', compact('users'));
    }

    public function new()
    {
        return view('admin.users.new');
    }

    public function create(Request $r)
    {
        Admin::query()->create([
            'username' => $r->get('username'),
            'password' => hash('sha256', $r->get('password'))
        ]);

        return redirect('/admin/users');
    }

    public function delete($id)
    {
        try {
            Admin::query()->find($id)->delete();
        } catch (\Exception $e) {

        }

        return redirect('/admin/users');
    }

    public function user($id)
    {
        try {
            $user = Admin::query()->find($id);

            return view('admin.users.edit', compact('user'));
        } catch (\Exception $e) {
            return redirect('/admin/users');
        }
    }

    public function edit($id, Request $r)
    {
        $user = Admin::query()->find($id);

        $user->update([
            'username' => $r->get('username'),
            'password' => hash('sha256', $r->get('password'))
        ]);

        return redirect('/admin/users/c/'. $id);
    }
}
