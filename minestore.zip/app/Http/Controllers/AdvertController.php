<?php

namespace App\Http\Controllers;

use App\Advert;
use Illuminate\Http\Request;

class AdvertController extends Controller
{
    public function get()
    {
        return self::getAdvert();
    }

    public static function getAdvert()
    {
        if (!$advert = Advert::query()->find(1)) {
            $advert = Advert::query()->create([
                'title' => '',
                'content' => '',
                'button_name' => '',
                'button_url' => ''
            ]);
        }

        return $advert;
    }
}
