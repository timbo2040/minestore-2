<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Invisnik\LaravelSteamAuth\SteamAuth;

class AuthController extends Controller
{
    /**
     * The SteamAuth instance.
     *
     * @var SteamAuth
     */
    protected $steam;

    /**
     * The redirect URL.
     *
     * @var string
     */
    protected $redirectURL = '/auth/callback';

    /**
     * AuthController constructor.
     *
     * @param SteamAuth $steam
     */
    public function __construct(SteamAuth $steam)
    {
        $this->steam = $steam;
    }

    public function username(Request $r)
    {
        $username = $r->get('username');

        $user = User::query()->where([['identificator', $username], ['system', 'minecraft']])->first();
        $token = Str::random(60);

        if (!$user) {
            User::create([
                'username' => $username,
                'avatar' => 'https://minotar.net/avatar/' . $username . '/28',
                'system' => 'minecraft',
                'identificator' => $username,
                'api_token' => $token
            ]);
        } else {
            $user->update([
                'api_token' => $token
            ]);
        }

        return $token;
    }

    public function steam()
    {
        return $this->steam->redirect();
    }

    public function steamHandle()
    {
        if ($this->steam->validate()) {
            $info = $this->steam->getUserInfo();

            if (!is_null($info)) {
                $user = User::query()->where([['identificator', $info->steamID64], ['system', 'steamid']])->first();
                $token = Str::random(60);

                if (!$user) {
                    User::create([
                        'username' => $info->personaname,
                        'avatar' => $info->avatarfull,
                        'system' => 'steamid',
                        'identificator' => $info->steamID64,
                        'api_token' => $token
                    ]);
                } else {
                    $user->update([
                        'api_token' => $token,
                        'avatar' => $info->avatarfull,
                        'username' => $info->personaname
                    ]);
                }

                return redirect($this->redirectURL . '?token=' . $token);
            }

            return redirect($this->redirectURL);
        }

        return redirect($this->redirectURL);
    }
}
