<?php

namespace App\Http\Controllers;

use App\Cart;
use App\CartItems;
use App\Coupon;
use App\Gift;
use App\Item;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function get(Request $r)
    {
        $user = $r->user();

        $cart = CartController::getCartByUserId($user->id);
        $items = [];

        foreach (CartItems::query()->where('cart_id', $cart->id)->get() as $item) {
            $product = Item::query()->find($item->item_id);

            $items[] = [
                'name' => $product->name,
                'price' => ItemsController::getPrice($product) * $item->count,
                'id' => $product->id,
                'count' => $item->count
            ];
        }

        return [
            'cart' => $cart,
            'items' => $items
        ];
    }

    public function addItem($id, Request $r)
    {
        $user = $r->user();
        $item = Item::query()->find($id);

        if (!$item) {
            return [
                'success' => false
            ];
        }

        $cart = CartController::getCartByUserId($user->id);
        $itemCart = CartItems::query()->where([['cart_id', $cart->id], ['item_id', $item->id]])->first();

        if ($itemCart) {
            $itemCart->update([
                'count' => $itemCart->count + 1
            ]);
        } else {
            CartItems::query()->create([
                'cart_id' => $cart->id,
                'item_id' => $item->id,
                'count' => 1
            ]);
        }

        $this->calculateCart($cart);

        return [
            'success' => true
        ];
    }

    public function removeItem($id, Request $r)
    {
        $user = $r->user();
        $item = Item::query()->find($id);

        if (!$item) {
            return [
                'success' => false
            ];
        }

        $cart = CartController::getCartByUserId($user->id);
        $itemCart = CartItems::query()->where([['cart_id', $cart->id], ['item_id', $item->id]])->first();

        if ($itemCart) {
            $itemCart->delete();
        }

        $this->calculateCart($cart);

        return [
            'success' => true
        ];
    }

    public function reloadItem($id, Request $r)
    {
        $user = $r->user();
        $item = Item::query()->find($id);
        $count = $r->get('count');

        if (!$item) {
            return [
                'success' => false
            ];
        }

        $cart = CartController::getCartByUserId($user->id);
        $itemCart = CartItems::query()->where([['cart_id', $cart->id], ['item_id', $item->id]])->first();

        if ($itemCart) {
            if (intval($count) === 0) {
                $itemCart->delete();
            } else {
                $itemCart->update([
                    'count' => $count
                ]);
            }
        }

        $this->calculateCart($cart);

        return [
            'success' => true
        ];
    }

    public function acceptCoupon(Request $r)
    {
        $coupon = $r->get('coupon');

        $bd = Coupon::query()->where('name', $coupon)->first();
        $gift = Gift::query()->where('name', $coupon)->first();

        if (!$bd && !$gift || $gift->end_balance <= 0) {
            return [
                'status' => false,
                'message' => 'Coupon not found'
            ];
        }

        $cart = self::getCartByUserId($r->user()->id);

        if ($bd) {
            if ($bd->available <= 0) {
                return [
                    'status' => false,
                    'message' => 'The coupon is over'
                ];
            }

            $cart->update([
                'coupon_id' => $bd->id
            ]);
            $bd->update([
                'available' => $bd->available - 1
            ]);

            self::calculateCart($cart);

            return [
                'success' => true,
                'message' => 'Successful Code Usage',
                'percent' => $bd->discount,
                'type' => 'coupon'
            ];
        } else if ($gift) {
            $endBalance = $gift->end_balance - $cart->price;
            if ($endBalance < 0) {
                $sum = $gift->end_balance;
            } else {
                $sum = $gift->end_balance - $endBalance;
            }

            $gift->update([
                'end_balance' => $gift->end_balance - $sum
            ]);

            $cart->update([
                'gift_sum' => $sum
            ]);

            self::calculateCart($cart);

            return [
                'success' => true,
                'message' => 'Successful Gift Usage ' . $sum . '$',
                'type' => 'gift'
            ];
        }
    }

    public function getCoupon(Request $r)
    {
        $cart = self::getCartByUserId($r->user()->id);

        if ($cart->coupon_id !== NULL) {
            try {
                $coupon = Coupon::query()->find($cart->coupon_id);

                return [
                    'percent' => $coupon->discount,
                    'coupon' => $coupon->name
                ];
            } catch (\Exception $e) {
                return [
                    'percent' => 0,
                    'coupon' => ''
                ];
            }
        } else {
            return [
                'percent' => 0,
                'coupon' => ''
            ];
        }
    }

    /**
     * @param $id
     * @return \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|object|null
     */
    public static function getCartByUserId($id)
    {
        $cart = Cart::query()->where([['user_id', $id], ['is_active', 1]])->orderBy('id', 'desc')->first();

        if (!$cart) {
            $cart = Cart::query()->create([
                'user_id' => $id,
                'items' => 0,
                'price' => 0.00
            ]);
        }

        return $cart;
    }

    /**
     * @param \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|object|null $item
     * @param \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|object|null $cart
     * @return boolean
     */
    public static function checkItemInCart($item, $cart)
    {
        if (CartItems::query()->where([['item_id', $item->id], ['cart_id', $cart->id]])->first()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Eloquent\Model|object|null $cart
     */
    private function calculateCart($cart)
    {
        $items = 0;
        $price = 0;

        foreach (CartItems::query()->where('cart_id', $cart->id)->get() as $item) {
            $product = Item::query()->find($item->item_id);

            $items += $item->count;
            $price += ItemsController::getPrice($product) * $item->count;
        }

        if ($cart->coupon_id !== NULL) {
            try {
                $coupon = Coupon::query()->find($cart->coupon_id);
                $discount = $price * ($coupon->discount / 100);
                $price = $price - $discount;
            } catch (\Exception $e) {

            }
        }

        if ($cart->gift_sum > 0) {
            $price = $price - $cart->gift_sum;
        }

        if ($price < 0) $price = 0;

        $cart->update([
            'items' => $items,
            'price' => $price
        ]);
    }
}
