<?php

namespace App\Http\Controllers;

use App\Category;
use App\Item;
use App\TopCategory;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{
    public function get()
    {
        $returnValue = [];

        $topCategories = TopCategory::query()->orderBy('sorting', 'asc')->get();

        foreach ($topCategories as $topCategory) {
            $categories = Category::query()->where('top_category_id', $topCategory->id)->orderBy('sorting', 'asc')->get();
            $urls = [];

            foreach ($categories as $category) {
                $urls[] = '/category/' . $category->url;
            }

            $returnValue[] = [
                'name' => $topCategory->name,
                'url' => $topCategory->url,
                'urls' => $urls,
                'categories' => $categories
            ];
        }

        return $returnValue;
    }

    public function getOne($url)
    {
        $category = CategoriesController::getCategory($url);
        $items = [];

        foreach (Item::query()->where('category_url', $url)->orderBy('sorting', 'asc')->get() as $item) {
            $discount = 0;
            if ($item->discount > 0) {
                $discount = $item->price;
            }

            $items[] = [
                'name' => $item->name,
                'price' => ItemsController::getPrice($item),
                'discount' => $discount,
                'image' => $item->image,
                'id' => $item->id
            ];
        }

        return [
            'category' => $category,
            'items' => $items
        ];
    }

    public static function getCategory($url)
    {
        $category = Category::query()->where('url', $url)->first();

        if ($category) return $category;

        $category = TopCategory::query()->where('url', $url)->first();

        if ($category) return $category;

        return null;
    }
}
