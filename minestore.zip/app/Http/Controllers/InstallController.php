<?php

namespace App\Http\Controllers;

use App\Admin;
use App\PaymentMethod;
use App\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class InstallController extends Controller
{
    public function index()
    {
        if (env('INSTALLED')) {
            return redirect('/');
        }

        return view('install.index');
    }

    public function install(Request $r)
    {
        if (env('INSTALLED')) {
            return redirect('/');
        }

        $password = '';

        if (strlen($r->get('DB_PASSWORD')) > 0) {
            $password = $r->get('DB_PASSWORD');
        }

        \App\Http\Controllers\SettingsController::setEnvironmentValue([
            'DB_HOST' => $r->get('DB_HOST'),
            'DB_PORT' => $r->get('DB_PORT'),
            'DB_DATABASE' => $r->get('DB_DATABASE'),
            'DB_USERNAME' => $r->get('DB_USERNAME'),
            'DB_PASSWORD' => $password
        ]);

        Artisan::call('config:clear');

        return redirect('/install/migration')->with('data', $r->all());
    }

    public function makeMigration(Request $r)
    {
        if (env('INSTALLED')) {
            return redirect('/');
        }

        Artisan::call('migrate');

        Setting::query()->create([
            'site_name' => session()->get('data')['site_name'],
            'serverIP' => session()->get('data')['serverIP'],
            'serverPort' => session()->get('data')['serverPort'],
            'withdraw_type' => session()->get('data')['withdraw_type'],
            'withdraw_game' => session()->get('data')['withdraw_game'],
            'webhook_url' => session()->get('data')['webhook_url'],
            'discord_guild_id' => session()->get('data')['discord_guild_id'],
            'discord_url' => session()->get('data')['discord_url'],
            'auth' => session()->get('data')['auth'],
            'index_content' => '',
            'index_deal' => 0
        ]);

        Admin::query()->create([
            'username' => 'admin',
            'password' => hash('sha256', 'admin'),
            'remember_token' => NULL
        ]);

        $this->makePayments();

        \App\Http\Controllers\SettingsController::setEnvironmentValue([
            'INSTALLED' => true
        ]);

        return view('install.success');
    }

    private function makePayments()
    {
        PaymentMethod::query()->create([
            'name' => 'PayPal',
            'enable' => 1,
            'config' => '{"test": "1", "paypal_user": "sb-jxnfr1127937_api1.business.example.com", "paypal_password": "CGLJZ6K4DVKGTUSA", "paypal_signature": "AVrjjHxCyHcPEssNOTQfSSnz6t8BAvAC-Ia.E3E2O1mM7dLlb5NKIs0-", "paypal_currency_code": "RUB"}'
        ]);

        PaymentMethod::query()->create([
            'name' => 'CoinPayments',
            'enable' => 1,
            'config' => '{"currency_code": "EUR", "secret_coinpayments": "1", "merchant_coinpayments": "test"}'
        ]);

        PaymentMethod::query()->create([
            'name' => 'G2APay',
            'enable' => 1,
            'config' => '{"hash": "123", "email": "213", "secret": "123"}'
        ]);

        PaymentMethod::query()->create([
            'name' => '2Checkout',
            'enable' => 1,
            'config' => '{"id": "1", "currency": "USD", "secret_word": "123"}'
        ]);
    }
}
