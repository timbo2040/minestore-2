<?php

namespace App\Http\Controllers;

use App\Cart;
use App\CartItems;
use App\Item;
use App\Payment;
use App\PaymentLibs\Rcon;
use App\PaymentLibs\RocketRCON;
use App\Server;
use App\Setting;
use App\User;
use Illuminate\Http\Request;

class ItemsController extends Controller
{
    public function getOne($id, Request $r)
    {
        $user = $r->user();
        $item = Item::query()->find($id);

        if (!$item) return [
            'success' => false
        ];

        return [
            'success' => true,
            'description' => $item->description,
            'price' => ItemsController::getPrice($item),
            'name' => $item->name,
            'id' => $item->id,
            'in_cart' => CartController::checkItemInCart($item, CartController::getCartByUserId($user->id))
        ];
    }

    public function getOneGuest($id)
    {
        $item = Item::query()->find($id);

        if (!$item) return [
            'success' => false
        ];

        return [
            'success' => true,
            'description' => $item->description,
            'price' => ItemsController::getPrice($item),
            'name' => $item->name,
            'id' => $item->id,
            'in_cart' => false
        ];
    }

    public static function giveItems($payment)
    {
        $setting = Setting::query()->find(1);
        $cart = Cart::query()->find($payment->cart_id);
        $itemsCart = CartItems::query()->where('cart_id', $cart->id)->get();
        $allServers = Server::query()->get();
        $username = User::query()->where('id', $payment->user_id)->pluck('identificator');
        foreach ($itemsCart as $iCart) {
            $product = Item::query()->find($iCart->item_id);
            $servers = [];

            if ($product->server) {
                $servers[] = $allServers[$product->server_id];
            } else {
                $servers = $allServers;
            }

            $result = false;

            foreach ($servers as $server) {
                if ($setting->withdraw_game === 'minecraft') {
                    if ($setting->withdraw_type === 'rcon') {
                        $result = ItemsController::giveRcon($server, $product, $username[0], $iCart->count);

                        if (!$result) ItemsController::sendErrorDiscordRcon($payment->id, $setting);
                    } else if ($setting->withdraw_type === 'plugin') {
                        $result = ItemsController::givePlugin($server, $product, $username[0], $iCart->count);

                        if (!$result) ItemsController::sendErrorDiscordPlugin($payment->id, $setting);
                    }
                } else if ($setting->withdraw_game === 'unturned') {
                    $result = ItemsController::giveRconUnturned($server, $product, $username[0], $iCart->count);

                    if (!$result) ItemsController::sendErrorDiscordPlugin($payment->id, $setting);
                }
            }

            if (!$result) {
                $payment->update([
                    'status' => Payment::ERROR
                ]);

                return false;
            }

            ItemsController::sendSuccessfulDiscord($username, ItemsController::getPrice($product), $iCart->count, $payment->id, $setting);
        }

        return true;
    }

    public static function giveRcon($server, $item, $username, $count)
    {
        $rcon = new RCON($server);
        if (@$rcon->connect()) {
            $commands = json_decode($item->commands, true);

            for ($i = 0; $i < $count; $i++) {
                foreach ($commands as $command) {
                    $cmd = str_replace("{user}", $username, $command);
                    $rcon->send_command($cmd);
                }
            };

            $rcon->disconnect();
        } else {
            return false;
        }

        return true;
    }

    public static function giveRconUnturned($server, $item, $username, $count)
    {
        $rcon = new RocketRCON();

        if ($rcon->connect($server->host_websocket, $server->port_websocket, $server->password_websocket)) {
            $commands = json_decode($item->commands, true);

            for ($i = 0; $i < $count; $i++) {
                foreach ($commands as $command) {
                    $cmd = str_replace("{user}", $username, $command);
                    $rcon->send($cmd);
                }
            }

            $rcon->disconnect();
        } else {
            return false;
        }

        return true;
    }

    public static function givePlugin($server, $item, $username, $count)
    {
        $commands = json_decode($item->commands, true);

        for ($i = 0; $i < $count; $i++) {
            foreach ($commands as $command) {
                $fp = fsockopen($server->host_websocket, $server->port_websocket, $errno, $errstr, 3);
                if ($fp !== FALSE) {
                    $cmd = str_replace("{user}", $username, $command);
                    $cmd = $server->password_websocket . " " . $cmd;
                    fwrite($fp, $cmd);

                    fclose($fp);
                } else {
                    return false;
                }
            }
        }

        return true;
    }

    public static function sendErrorDiscordRcon($id, $setting)
    {
        $msg = ':red_circle: Connection Lost (RCON). Order: #' . $id;

        $json_data = array('content' => "$msg");
        $make_json = json_encode($json_data);

        $ch = curl_init($setting->webhook_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_exec($ch);
    }

    public static function sendErrorDiscordPlugin($id, $setting)
    {
        $msg = ':red_circle: Connection Lost (RCON). Order: #' . $id;

        $json_data = array('content' => "$msg");
        $make_json = json_encode($json_data);

        $ch = curl_init($setting->webhook_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_exec($ch);
    }

    public static function sendSuccessfulDiscord($username, $price, $count, $id, $setting)
    {
        $msg = ':green_circle: ' . $username . ' bought rank for ' . $price . '$ (' . $count . ' length). Order: #' . $id;

        $json_data = array('content' => "$msg");
        $make_json = json_encode($json_data);

        $ch = curl_init($setting->webhook_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_exec($ch);
    }

    public static function getPrice($item)
    {
        if ($item->discount > 0) {
            $discount = $item->price * ($item->discount / 100);
            return round($item->price - $discount, 2);
        } else {
            return $item->price;
        }
    }
}
