<?php

namespace App\Http\Controllers;

use App\Page;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function get(Request $r)
    {
        $url = $r->get('url');
        $page = Page::query()->where('url', $url)->first();

        if ($page) {
            return [
                'success' => true,
                'page' => $page
            ];
        } else {
            return [
                'success' => false
            ];
        }
    }
}
