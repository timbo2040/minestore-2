<?php

namespace App\Http\Controllers;

use App\Cart;
use App\Payment;
use App\PaymentLibs\G2A;
use App\PaymentMethod;
use App\Setting;
use Illuminate\Http\Request;
use App\PaymentLibs\PayPal;

class PaymentController extends Controller
{
    public function get()
    {
        $paymentMethods = PaymentMethod::query()->where('enable', 1)->get();
        $payments = [];

        foreach ($paymentMethods as $payment) {
            $payments[] = [
                'name' => $payment->name
            ];
        }

        return $payments;
    }

    public function create(Request $r)
    {
        $user = $r->user();
        $paymentMethod = $r->get('paymentMethod');
        $data = [];

        $cart = CartController::getCartByUserId($user->id);

        if ($cart->items === 0) {
            return [
                'success' => false,
                'message' => 'Take items'
            ];
        }

        $payment = Payment::create([
            'user_id' => $user->id,
            'cart_id' => $cart->id,
            'price' => $cart->price,
            'status' => Payment::PROCESSED
        ]);

        switch ($paymentMethod) {
            case "PayPal":
                $data = $this->paypalMethod($cart, $payment);
                break;
            case "CoinPayments":
                $data = $this->CoinPaymentsMethod($cart, $payment);
                break;
            case "G2APay":
                $data = $this->G2AMethod($cart, $payment);
                break;
            case "2Checkout":
                $data = $this->TwoCheckoutMethod($cart, $payment);
                break;
        }

        return [
            'success' => true,
            'data' => $data
        ];
    }

    private function paypalMethod($cart, $payment)
    {
        $paymentMethod = PaymentMethod::query()->where('name', 'PayPal')->first();
        if (!$paymentMethod->enable) return;
        $config = json_decode($paymentMethod->config, true);
        $paypal = new PayPal([
            "environment" => $config['test'] ? "sandbox" : "live",
            "user" => $config['paypal_user'],
            "pwd" => $config['paypal_password'],
            "signature" => $config['paypal_signature'],
            "version" => 113
        ]);

        $array = [
            'method' => 'SetExpressCheckout',
            'PAYMENTREQUEST_0_PAYMENTACTION' => 'Sale',
            'PAYMENTREQUEST_0_AMT' => $cart->price,
            'PAYMENTREQUEST_0_CURRENCYCODE' => $config['paypal_currency_code'],
            'returnurl' => 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . 'api/payments/handle/paypal?id=' . $payment->id . '&ip=' . $_SERVER['REMOTE_ADDR'],
            'cancelurl' => 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF'])
        ];

        $result = $paypal->call($array);

        if ($result['ACK'] == 'Success') {
            $cart->update([
                'is_active' => 0
            ]);
            return [
                'type' => 'url',
                'url' => $paypal->redirect($result)
            ];
        } else {
            return [];
        }
    }

    private function CoinPaymentsMethod($cart, $payment)
    {
        $paymentMethod = PaymentMethod::query()->where('name', 'CoinPayments')->first();
        if (!$paymentMethod->enable) return;
        $config = json_decode($paymentMethod->config, true);

        $cart->update([
            'is_active' => 0
        ]);

        return [
            'type' => 'html',
            'html' => '<form id="coinpayments" style="display:none;" action="https://www.coinpayments.net/index.php" method="post">
              <input type="hidden" name="cmd" value="_pay_simple">
              <input type="hidden" name="reset" value="1">
              <input type="hidden" name="merchant" value="' . $config['merchant_coinpayments'] . '">
              <input type="hidden" name="currency" value="' . $config['currency_code'] . '">
              <input type="hidden" name="buyer_email" value="test@test.com">
              <input type="hidden" name="item_name" value="Funding">
              <input type="hidden" name="item_desc" value="Transaction for upping balance on site">
              <input type="hidden" name="custom" value="' . $payment->id . '">
              <input type="hidden" name="want_shipping" value="0">
              <input type="hidden" name="success_url" value="http://' . $_SERVER['HTTP_HOST'] . '">
              <input type="hidden" name="ipn_url" value="http://' . $_SERVER['HTTP_HOST'] . '/api/payments/handle/coinpayments">
              <input type="hidden" name="amountf" value="' . $cart->price . '">
            </form>'
        ];
    }

    private function G2AMethod($cart, $payment)
    {
        $paymentMethod = PaymentMethod::query()->where('name', 'G2APay')->first();
        if (!$paymentMethod->enable) return;
        $config = json_decode($paymentMethod->config, true);

        $g2apay = new G2A($config["hash"], $config["secret"], $config["email"]);

        $result = $g2apay->createOrder(array($payment->id, []));

        if (isset($result['success']) && $result['success'] !== false){
            return [
                'type' => 'url',
                'url' => $result['url']
            ];
        } else {
            return [];
        }
    }

    private function TwoCheckoutMethod($cart, $payment)
    {
        $paymentMethod = PaymentMethod::query()->where('name', '2Checkout')->first();
        if (!$paymentMethod->enable) return;
        $config = json_decode($paymentMethod->config, true);

        $cart->update([
            'is_active' => 0
        ]);

        return [
            'type' => 'html',
            'html' => "<form id=pay name=pay action='https://2checkout.com/checkout/purchase' method='post'>
                  <input type='hidden' name='sid' value='" . $config['id'] . "' />
                  <input type='hidden' name='mode' value='2CO' />
                  <input type='hidden' name='li_0_name' value='Product purchase' />
                  <input type='hidden' name='li_0_price' value='" . $cart->price . "' />
                  <input type='hidden' name='li_0_tangible' value='N' />
                  <input type='hidden' name='currency_code' value='" . $config['currency'] . "' />
                  <input type='hidden' name='merchant_order_id' value='" . $payment->id . "'>
                  <input type='hidden' name='demo' value='Y' />
                  <input type='submit' />
                </form>"
        ];
    }

    public function paypalHandle(Request $r)
    {
        $id = $r->get('id');

        $payment = Payment::query()->with(['user'])->where([['id', $id], ['status', Payment::PROCESSED]])->first();

        if (!$payment) {
            return redirect('/');
        }

        $paymentMethod = PaymentMethod::query()->where('name', 'PayPal')->first();
        $config = json_decode($paymentMethod->config, true);
        $cart = Cart::query()->find($payment->cart_id);

        $paypal = new PayPal([
            "environment" => $config['test'] ? "sandbox" : "live",
            "user" => $config['paypal_user'],
            "pwd" => $config['paypal_password'],
            "signature" => $config['paypal_signature'],
            "version" => 113
        ]);

        $result = $paypal->call(array(
            'method' => 'DoExpressCheckoutPayment',
            'PAYMENTREQUEST_0_PAYMENTACTION' => 'Sale',
            'PAYMENTREQUEST_0_AMT' => $cart->price,
            'PAYMENTREQUEST_0_CURRENCYCODE' => $config['paypal_currency_code'],
            'token' => $r->get('token'),
            'payerid' => $r->get('PayerID')
        ));

        if (!isset($result['PAYMENTINFO_0_PAYMENTSTATUS']) || $result['PAYMENTINFO_0_PAYMENTSTATUS'] != 'Completed') {
            $payment->update([
                'status' => Payment::ERROR
            ]);
            return redirect('/');
        }

        $settings = Setting::query()->find(1);
        $settings->update([
            'index_goal_sum' => $settings->index_goal_sum + $payment->price
        ]);

        $payment->update([
            'status' => Payment::PAID
        ]);

        ItemsController::giveItems($payment);

        return redirect('/');
    }

    public function CoinPaymentsHandle(Request $r)
    {
        $merchant = isset($_POST['merchant']) ? $_POST['merchant'] : '';
        if (empty($merchant)) {
            die("No Merchant ID passed");
        }

        if ($merchant != $this->config->merchant_coinpayments) {
            die("Invalid Merchant ID");
        }

        $request = file_get_contents('php://input');
        if ($request === FALSE || empty($request)) {
            die("Error reading POST data");
        }

        $paymentMethod = PaymentMethod::query()->where('name', 'CoinPayments')->first();
        $config = json_decode($paymentMethod->config, true);

        $hmac = hash_hmac("sha512", $request, $config['secret_coinpayments']);
        if ($hmac != $_SERVER['HTTP_HMAC']) {
            die("HMAC signature does not match");
        }

        if (intval($_POST['status']) < 99 AND intval($_POST['status']) != 2) {
            die('Invalid status');
        }

        $payment = Payment::query()->with(['user'])->where([['id', $_POST['custom']], ['status', Payment::PROCESSED]])->first();

        if (!$payment) {
            die('User not found');
        }

        $settings = Setting::query()->find(1);
        $settings->update([
            'index_goal_sum' => $settings->index_goal_sum + $payment->price
        ]);

        $payment->update([
            'status' => Payment::PAID
        ]);

        ItemsController::giveItems($payment);

        die('Accept order, accept code');
    }

    public function G2AHandle(Request $r)
    {
        $orderId = $r->get('order_id');

        $payment = Payment::query()->with(['user'])->where([['id', $orderId], ['status', Payment::PROCESSED]])->first();

        if (!$payment) {
            die('Not found payment');
        }

        $settings = Setting::query()->find(1);
        $settings->update([
            'index_goal_sum' => $settings->index_goal_sum + $payment->price
        ]);

        $payment->update([
            'status' => Payment::PAID
        ]);

        ItemsController::giveItems($payment);

        die('Accept order, accept code');
    }

    public function TwoCheckoutHandle(Request $r)
    {
        $paymentMethod = PaymentMethod::query()->where('name', '2Checkout')->first();
        if (!$paymentMethod->enable) return;
        $config = json_decode($paymentMethod->config, true);

        $hashSecretWord = $config['secret_word'];
        $hashSid = $config['id'];
        $hashTotal = $r->get('total');
        $hashOrder = $r->get('order_number');
        $StringToHash = strtoupper(md5($hashSecretWord . $hashSid . $hashOrder . $hashTotal));

        if ($StringToHash !== $_REQUEST['key']) {
            exit('Fail - Hash Mismatch');
        }

        $id = $_REQUEST['merchant_order_id'];

        $payment = Payment::query()->with(['user'])->where([['id', $id], ['status', Payment::PROCESSED]])->first();

        if (!$payment) {
            die('Not found payment');
        }

        $settings = Setting::query()->find(1);
        $settings->update([
            'index_goal_sum' => $settings->index_goal_sum + $payment->price
        ]);

        $payment->update([
            'status' => Payment::PAID
        ]);

        ItemsController::giveItems($payment);

        die('Accept order, accept code');
    }
}
