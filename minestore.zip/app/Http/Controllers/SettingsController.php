<?php

namespace App\Http\Controllers;

use App\Item;
use App\Link;
use App\Payment;
use App\Setting;
use App\User;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function get()
    {
        $settings = Setting::query()->find(1);
        $header = Link::query()->where('type', Link::SHOW_HEADER)->orWhere('type', Link::SHOW_ALL)->get();
        $footer =  Link::query()->where('type', Link::SHOW_FOOTER)->orWhere('type', Link::SHOW_ALL)->get();

        $deal = null;
        if ($settings->index_deal) {
            try {
                $item = Item::query()->find($settings->index_deal);

                $discount = 0;
                if ($item->discount > 0) {
                    $discount = $item->price;
                }

                $deal = [
                    'name' => $item->name,
                    'price' => ItemsController::getPrice($item),
                    'discount' => $discount,
                    'image' => $item->image,
                    'id' => $item->id
                ];
            } catch (\Exception $e) {

            }
        }

        $lastPayments = Payment::query()->with(['user'])->where('status', Payment::PAID)->orderBy('id', 'desc')->limit(8)->get();
        $last = [];

        foreach ($lastPayments as $payment) {
            $last[] = [
                'avatar' => $payment->user->avatar,
                'username' => $payment->user->username
            ];
        }

        $guildId = $settings->discord_guild_id;

        try {
            $onlineDiscord = \Cache::remember('discord_online', 120, function () use ($guildId) {
                $members = json_decode(file_get_contents('https://discordapp.com/api/guilds/' . $guildId . '/widget.json'), true)['members'];
                $membersCount = 1;

                foreach ($members as $member) {
                    if ($member['status'] == 'online') {
                        $membersCount++;
                    }
                }

                return $membersCount;
            });
        } catch (\Exception $e) {
            $onlineDiscord = 0;
        }

        $topPayment = Payment::query()->where('status', Payment::PAID)
            ->select(
                '*',
                \DB::raw("SUM(price) as total_sum")
            )
            ->groupBy('user_id')
            ->orderBy('total_sum', 'desc')
            ->first();
        $top = [];

        if ($topPayment) {
            $user = User::query()->find($topPayment->user_id);

            $top = [
                'avatar' => 'https://mc-heads.net/body/' . $user->identificator,
                'username' => $user->username
            ];
        }

        return [
            'auth' => $settings->auth,
            'header' => $header,
            'footer' => $footer,
            'website_name' => $settings->site_name,
            'server' => [
                'ip' => $settings->serverIP,
                'port' => $settings->serverPort
            ],
            'deal' => $deal,
            'content' => $settings->index_content,
            'goal' => $settings->index_goal,
            'goal_sum' => $settings->index_goal_sum,
            'top' => $top,
            'lastPayments' => $last,
            'discord' => [
                'online' => $onlineDiscord,
                'url' => $settings->discord_url
            ]
        ];
    }

    public static function setEnvironmentValue(array $values)
    {
        $envFile = app()->environmentFilePath();
        $str = file_get_contents($envFile);

        if (count($values) > 0) {
            foreach ($values as $envKey => $envValue) {

                $str .= "\n"; // In case the searched variable is in the last line without \n
                $keyPosition = strpos($str, "{$envKey}=");
                $endOfLinePosition = strpos($str, "\n", $keyPosition);
                $oldLine = substr($str, $keyPosition, $endOfLinePosition - $keyPosition);

                // If key does not exist, add it
                if (!$keyPosition || !$endOfLinePosition || !$oldLine) {
                    $str .= "{$envKey}={$envValue}\n";
                } else {
                    $str = str_replace($oldLine, "{$envKey}={$envValue}", $str);
                }

            }
        }

        $str = substr($str, 0, -1);
        if (!file_put_contents($envFile, $str)) return false;
        return true;
    }
}
