<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{
    const NO_SHOW = 0;
    const SHOW_FOOTER = 1;
    const SHOW_HEADER = 2;
    const SHOW_ALL = 3;

    protected $fillable = [
        'name', 'url', 'type'
    ];
}
