<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    const PROCESSED = 0;
    const PAID = 1;
    const ERROR = 2;

    protected $fillable = [
        'user_id', 'cart_id', 'price', 'status'
    ];

    public function user()
    {
        return $this->belongsTo('App\User', 'user_id', 'id');
    }

    public function cart()
    {
        return $this->belongsTo('App\Cart', 'cart_id', 'id');
    }
}
