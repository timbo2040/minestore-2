<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Server extends Model
{
    protected $fillable = [
        'name', 'host', 'port', 'password', 'host_websocket', 'port_websocket', 'password_websocket'
    ];
}
