<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
        'site_name', 'serverIP', 'serverPort', 'withdraw_type', 'withdraw_game', 'webhook_url', 'auth',
        'index_deal', 'index_goal', 'index_goal_sum', 'index_content', 'discord_guild_id', 'discord_url'
    ];
}
