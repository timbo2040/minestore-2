import Vue from 'vue';
import router from './router';
import VueAxios from 'vue-axios';
import axios from 'axios';
import VueCookie from 'vue-cookie';

Vue.use(VueAxios, axios);
Vue.use(VueCookie);

axios.defaults.baseURL = '/api';

import App from "./pages/App";

const app = new Vue({
    el: '#app',
    data: {
        user: null,
        cart: {
            items: 0,
            price: 0
        },
        cartItems: null,
        settings: {
            server: {
                ip: ''
            },
            header: [],
            footer: [],
            website_name: '',
            deal: null,
            content: '',
            goal: 0,
            discord: {
                online: 0,
                url: ''
            },
            top: {},
            goal_sum: 0
        }
    },
    methods: {
        async getUser() {
            axios.defaults.headers.common['Authorization'] = 'Bearer ' + this.$cookie.get('token');

            try {
                const response = await axios.post('/user');
                this.user = response.data;

                this.getCart();
            } catch (e) {
                this.user = null;
                this.$cookie.delete('token');
            }
        },
        async getCart() {
            const response = await axios.post('/cart/get');
            this.cart = response.data.cart;
            this.cartItems = response.data.items;
        },
        async getSettings() {
            const response = await axios.post('/settings/get');

            this.settings = response.data;
        },
        showNotification(type, message) {
            toastr[type](message);
        }
    },
    created() {
        this.getSettings();
        if (this.$cookie.get('token')) {
            this.getUser();
            this.getCart();
        }
    },
    router,
    components: {
        App
    }
});
