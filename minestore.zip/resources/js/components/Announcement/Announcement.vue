<template>
    <div id="mstr-sale-announcement" v-if="advert.content.length > 0">
        <i class="sale-icon mdi mdi-message-alert-outline"></i>
        <div class="sale-text">
            <span class="big">{{ advert.title }}</span>
            <span class="small" v-html="advert.content"></span>
        </div>
        <a :href="advert.button_url" class="sale-btn">{{ advert.button_name }}</a>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                advert: {
                    title: '',
                    content: '',
                    button_name: '',
                    button_url: ''
                }
            }
        },
        async mounted() {
            const response = await this.$root.axios.post('/announcement/get');

            this.advert = response.data;
        }
    }
</script>
