<template>
    <div class="panel panel-default panel--mstr-login">
        <div class="panel-heading">Login</div>
        <div class="panel-body">
            <span class="mstr-login-tip">Please enter your username to continue</span>
            <form v-on:submit.prevent="onSubmit">
                <div class="username">
                    <div class="input-group">
                        <input type="text" v-model="username" name="ign" class="form-control input-lg form-control-lg">
                        <div class="input-group-append input-group-btn">
                            <button class="btn btn-success btn-lg" type="submit">Continue<i class="fa fa-chevron-right ml-2" style="margin-left:10px;"></i></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                username: ''
            }
        },
        methods: {
            async onSubmit() {
                const response = await this.$root.axios.post('/auth/username', {
                    username: this.username
                });

                this.$cookie.set('token', response.data);
                this.$root.getUser();

                this.$router.go(-1);
            }
        },
        mounted() {

        }
    }
</script>
