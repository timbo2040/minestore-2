<template>
    <div class="panel panel-default mstr-module is--goal" style="padding: 14px 14px 2px 0;" v-if="$root.settings.goal > 0">
        <div class="goal-text" style="text-align: center; font-size: 14pt;">
            <span class="left" style="font-weight: bold;">OUR GOAL</span>
        </div>
	<hr>
	<div class="right" style="margin-left: 104px;">{{ $root.settings.goal_sum }}.00 / {{ $root.settings.goal }} USD | {{ (100 * $root.settings.goal_sum / $root.settings.goal).toFixed(0) }}%</div>
        <br>
	<div class="goal-progress progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" :style="'width:' + (100 * $root.settings.goal_sum / $root.settings.goal).toFixed(0) +'%'">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Goal"
    }
</script>
