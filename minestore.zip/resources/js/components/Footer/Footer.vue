<template>
    <div class="mstr-default-footer">
        <div class="container">
                <span>
                  2020 © <b>{{ $root.settings.website_name }}</b>. All Rights Reserved.
                  <small>We are not affiliated with Mojang AB.</small>
			<small><a href="https://www.mc-market.org/resources/14184/">Powered by MineStore</a></small>
                </span>
                <span v-for="foot in $root.settings.footer">
                    <a :href="foot.url">{{ foot.name }}</a>
                </span>
        </div>
    </div>
</template>

<script>
    export default {}
</script>
