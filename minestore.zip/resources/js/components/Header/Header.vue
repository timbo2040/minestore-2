<template>
    <div id="mstr-header">
        <div class="header-top">
            <div class="container">
                <div class="link link--back">
                    <span v-for="head in $root.settings.header">
                        <a :href="head.url">{{ head.name }}</a>
                    </span>
                </div>
                <div class="link link--currency dropdown">

                </div>
                <div class="link link--logout">
                    <a v-if="$root.user === null" class="link-item disabled">
                        <b>Guest</b>
                        <img class="avatar-full" src="https://cravatar.eu/helmavatar/Steve/28.png" alt="Guest">
                    </a>
                    <a v-else @click="logout" style="cursor: pointer" class="link-item">
                        <b>Logout</b>
                        <img class="avatar-full" :src="$root.user.avatar" :alt="$root.user.username">
                    </a>
                </div>
            </div>
        </div>
        <div class="header-logo" href="/"></div>
        <div class="header-nav">
            <div class="container">
                <div class="nav-inner">
                    <a :href="$root.settings.discord.url" target="_blank" style="text-decoration: none;" class="box box--discord mstr-js--discordinvite">
                        <div class="box-toggle">
                            <i class="box-icon mdi mdi-discord"></i>
                            <div class="box-text">
                                <span class="big"><span class="big_mobile">Join</span>Discord</span>
                                <span class="small">
								<b class="mstr-js--discordcount">{{ $root.settings.discord.online }}</b>
								<b class="small_mobile">MEMBERS</b> ONLINE
							</span>
                            </div>
                        </div>
                    </a>

                    <div class="box box--ip mstr-js--copyip">
                        <div class="ip-count mstr-js--playercount">{{ online }}</div>
                        <div class="ip-value">{{ $root.settings.server.ip }}</div>
                    </div>

                    <div class="box box--cart mstr-component-cart mstr-js--cartParent"
                         :class="[openCart ? 'is--open' : '']" @click="openAndCloseCart">
                        <div v-if="$root.user === null" class="box-toggle cart-toggle cart-toggle--guest">
                            <div class="toggle-text">
                                    <span class="big">
                                        <span class="big_mobile">Welcome</span>
                                        <span class="big_normal">Welcome</span>
                                    </span>
                                <span class="small">
                                        NOT LOGGED IN
                                    </span>
                            </div>
                            <i class="toggle-icon mdi mdi-cart-outline"></i>
                        </div>
                        <div v-if="$root.user !== null" class="box-toggle cart-toggle mstr-js--cartToggle">
                            <div class="toggle-text">
                                <span class="big">
                                    <span class="big_mobile">Cart ({{ $root.cart.items }})</span>
                                    <span class="big_normal">Player's Cart</span>
                                </span>
                                <span class="small" v-if="$root.cart.items === 0">
                                    CART EMPTY
                                    <em></em>
                                    <span class="small_normal">LOGOUT</span>
                                </span>
                                <span v-else class="small">
                                    <span class="small_normal">{{ $root.cart.items }} ITEM</span>
                                    <em></em>
                                    {{ $root.cart.price.toFixed(2) }} USD
                                </span>
                            </div>
                            <i class="toggle-icon mdi mdi-cart-outline">
                                <span class="cart-number">{{ $root.cart.items }}</span>
                            </i>
                        </div>
                        <div v-if="$root.user !== null" class="cart-dropdown mstr-js--cartDropdown">
                            <div class="cart-controls">
                                <a class="logout btn btn-danger toggle-tooltip" title="" @click="logout"
                                   data-original-title="Shopping as Player">Log Out</a>
                            </div>

                            <div class="cart-items" v-if="$root.cart.items > 0">
                                <div class="item" v-for="item in $root.cartItems">
                                    <div class="item-info">
                                        <span class="item-name">{{ item.name }}</span>
                                        <span class="item-price">{{ item.price.toFixed(2) }} USD</span>
                                    </div>
                                    <a @click="removeInCart(item.id)" class="item-remove"><i
                                        class="fa fa-times"></i></a>
                                </div>
                            </div>

                            <div class="cart-checkout" v-if="$root.cart.items > 0">
                                <router-link tag="a" :to="{name: 'checkout'}" class="btn btn-success">
                                    Checkout <span class="badge">{{ $root.cart.price.toFixed(2) }} USD</span>
                                </router-link>
                            </div>

                            <div class="cart-empty" v-if="$root.cart.items === 0">
                                <b>Your Cart is Empty</b>
                                <small>Keep adding items to cart and check back here to complete your purchase!</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                openCart: false,
                online: 0
            }
        },
        methods: {
            logout() {
                this.$cookie.delete('token');
                this.$root.getUser();

                this.$router.push({name: 'index'});
            },
            openAndCloseCart() {
                if (this.openCart) {
                    this.openCart = false;
                } else {
                    this.openCart = true;
                }
            },
            async removeInCart(id) {
                const response = await this.$root.axios.post(`/cart/remove/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} remove in Cart`);
                }
            },
            async getOnlineServer() {
                $.get(`https://mcapi.us/server/status?ip=${this.$root.settings.server.ip}&port=${this.$root.settings.server.port}`, (result) => {
                    if (result.online) {
                        this.online = result.players.now;
                    }
                });
            }
        },
        mounted() {
            setTimeout(() => {
                this.getOnlineServer();

                setInterval(() => {
                    this.getOnlineServer();
                }, 3000);

                $(".mstr-js--copyip").length && new ClipboardJS(".mstr-js--copyip", {text: () => this.$root.settings.server.ip}).on("success", n => {
                    swal("Server IP Copied", "We hope to see you online soon!", "success")
                })
            }, 300);
        }
    }
</script>
