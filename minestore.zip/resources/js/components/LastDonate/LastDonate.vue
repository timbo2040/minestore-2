<template>
    <div class="panel panel-default mstr-module module--payments">
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
width="30" height="30"
viewBox="0 0 172 172"
style=" fill:#000000;     margin-left: 10px;
    margin-right: 10px;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M54.88379,14.33333c-5.70944,0 -10.91987,3.43398 -13.17155,8.67839l-17.77669,41.48828h-9.58822c-2.24317,0 -4.34927,1.04297 -5.71094,2.82747c-1.34733,1.77733 -1.80544,4.08567 -1.21777,6.24284l18.35059,66.40365c1.71283,6.192 7.3941,10.52604 13.81543,10.52604h92.83073c6.42133,0 12.09577,-4.32721 13.80144,-10.51205l18.35059,-66.40365c0.59483,-2.15717 0.14356,-4.4795 -1.20378,-6.25684c-1.36167,-1.7845 -3.47494,-2.82747 -5.71094,-2.82747h-9.58822l-17.79069,-41.47428h0.014c-2.24814,-5.26874 -7.47611,-8.69238 -13.18555,-8.69238zM54.88379,28.66667h62.21843l15.35514,35.83333h-92.91471zM23.75358,78.83333h124.49284l-15.84506,57.33333h-92.81673zM57.33333,93.16667c-3.956,0 -7.16667,3.21067 -7.16667,7.16667v14.33333c0,3.956 3.21067,7.16667 7.16667,7.16667c3.956,0 7.16667,-3.21067 7.16667,-7.16667v-14.33333c0,-3.956 -3.21067,-7.16667 -7.16667,-7.16667zM86,93.16667c-3.956,0 -7.16667,3.21067 -7.16667,7.16667v14.33333c0,3.956 3.21067,7.16667 7.16667,7.16667c3.956,0 7.16667,-3.21067 7.16667,-7.16667v-14.33333c0,-3.956 -3.21067,-7.16667 -7.16667,-7.16667zM114.66667,93.16667c-3.956,0 -7.16667,3.21067 -7.16667,7.16667v14.33333c0,3.956 3.21067,7.16667 7.16667,7.16667c3.956,0 7.16667,-3.21067 7.16667,-7.16667v-14.33333c0,-3.956 -3.21067,-7.16667 -7.16667,-7.16667z"></path></g></g></svg>        <div class="payments-list">
            <div class="payment toggle-tooltip" v-for="payment in $root.settings.lastPayments"
                 title="" data-html="true" :data-original-title="'<b>' + payment.username + '</b><br/><small></small>'">
                <img width="28" height="28" :src="payment.avatar" :alt="payment.username">
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>
