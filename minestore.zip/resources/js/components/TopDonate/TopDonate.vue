<template>
    <div class="panel panel-default mstr-module module--topdonor">
        <div class="donor-img">
            <img :src="$root.settings.top.avatar" :alt="$root.settings.top.username">
        </div>
        <div class="donor-text">
            <span class="big">{{ $root.settings.top.username }} </span>
            <span class="small">this month's top donator</span>
        </div>
    </div>
</template>
