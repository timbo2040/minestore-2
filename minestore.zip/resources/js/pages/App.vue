<template>
    <div>
        <Header />
        <div class="mstr-body">
            <div class="container">
                <Announcement />
                <div id="mstr-page">
                    <div class="page-sidebar">
                        <div id="mstr-sidebar-nav" class="panel panel-default">
                            <div class="nav-header">
                                <div class="nav-title">Store Menu</div>
                                <button class="nav-toggle" onclick="$('#mstr-sidebar-nav').toggleClass('is--open')">
                                    <i class="mdi mdi-menu"></i>
                                </button>
                            </div>
                            <div class="nav-collapse">
                                <div class="nav-items">
                                    <li :class="[$route.name === 'index' ? 'active' : '']">
                                        <router-link tag="a" class="nav-link" :to="{name: 'index'}">
                                            <span class="nav-link-icon home"></span> <b>Home</b>
                                        </router-link>
                                    </li>

                                    <li v-for="category in categories"
                                        :class="[[category.categories.length > 0 ? 'dropdown' : ''],
                                         [$route.fullPath === `/category/${category.url}` ? 'active': ''],
                                         [category.urls.indexOf($route.fullPath) !== -1 ? 'active' : '']]"
                                    >
                                        <a v-if="category.categories.length > 0" href="javascript:;" class="nav-link" data-toggle="dropdown">
                                            {{ category.name }}
                                            <i class="mdi mdi-menu-down"></i>
                                        </a>
                                        <div class="nav-dd" v-if="category.categories.length > 0">
                                            <router-link v-for="cat in category.categories"
                                                         :to="{name: 'category', params: {url: cat.url}}"
                                                         class="dropdown-link"
                                                >{{ cat.name }}
                                            </router-link>
                                        </div>
                                        <router-link v-else :to="{name: 'category', params: {url: category.url}}" class="nav-link">
                                            {{ category.name }}
                                        </router-link>
                                    </li>
                                </div>
                            </div>
                        </div>
                        <Goal />
                        <TopDonate />
                        <LastDonate />
                    </div>
                    <div class="page-main">
                        <div class="body">
                            <div class="content">
                                <router-view />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>

<script>
    import Header from "../components/Header/Header";
    import Footer from "../components/Footer/Footer";
    import Announcement from "../components/Announcement/Announcement";
    import TopDonate from "../components/TopDonate/TopDonate";
    import LastDonate from "../components/LastDonate/LastDonate";
    import Goal from "../components/DonationGoal/Goal";

    export default {
        components: {
            Goal,
            Header,
            Footer,
            Announcement,
            TopDonate,
            LastDonate
        },
        data() {
            return {
                categories: {}
            }
        },
        methods: {
            async getCategories() {
                const response = await this.$root.axios.post('/categories/get');

                this.categories = response.data;
            }
        },
        created() {
            $('body').tooltip({
                selector: '[data-toggle="tooltip"]',
                container: '.modal-footer'
            });

            $(".toggle-tooltip").tooltip();

            this.getCategories();
        }
    }
</script>
