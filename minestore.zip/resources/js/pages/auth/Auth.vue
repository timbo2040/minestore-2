<template>
    <div>
        <EnterUsername v-if="method === 'username'" />
        <EnterSteamid v-if="method === 'steamid'"/>
    </div>
</template>

<script>
    import EnterSteamid from "../../components/Auth/EnterSteamid";
    import EnterUsername from "../../components/Auth/EnterUsername";

    export default {
        components: {
            EnterSteamid,
            EnterUsername
        },
        data() {
            return {
                method: ''
            }
        },
        created() {
            setTimeout(() => {
                this.method = this.$root.settings.auth;
            }, 300);
        }
    }
</script>
