<template>
    <div>
        <div class="panel panel-default">
            <div class="panel-heading">{{ category.name }}</div>
            <div class="panel-body">
                <div class="category">
                    <div class="packages-image">
                        <div class="package mstr-box" v-for="item in items">
                            <div class="image">
                                <a @click="showDescription(item.id)" class="toggle-modal">
                                    <img :src="item.image" class="toggle-tooltip package-image" title="" data-original-title="Click for more details">
                                </a>
                            </div>
                            <div class="info">
                                <div class="text">
                                    <div class="name">{{ item.name }}
                                    </div>
                                    <div class="price">
                                        <span class="discount" v-if="item.discount > 0">{{ item.discount.toFixed(2) }}</span>
                                        {{ item.price.toFixed(2) }} <small>USD</small>
                                    </div>
                                </div>
                                <div class="button">
                                    <a @click="showDescription(item.id)" class="btn btn-sm btn-success btn-block toggle-modal">Buy</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="popup-modal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title">{{ item.name }}</h4>
                    </div>
                    <div class="modal-body" v-html="item.description">

                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-4">
                                <p class="pull-left">
                                    <b>{{ item.price.toFixed(2) }} <small>USD</small></b>
                                </p>
                            </div>
                            <div class="col-sm-8">
                                <div style="display: inline-block;" class="package-footer-buttons" v-if="$root.user !== null">
                                    <a class="btn btn-success gift-weight" v-if="!item.in_cart" @click="addToCart(item.id)">Add to cart</a>
                                    <a class="btn btn-danger gift-weight" v-if="item.in_cart" @click="removeInCart(item.id)">Remove</a>
                                </div>
<!--                                <btn class="btn gift-weight btn-gift ">Gift this package <i class="fa fa-chevron-down"-->
<!--                                                                                            aria-hidden="true"></i>-->
<!--                                </btn>-->
                            </div>
                        </div>
<!--                        <div class="row gift-fields">-->
<!--                            <form name="gift-form" method="get" action="/checkout/packages/add/2116246/single/gift">-->
<!--                                <div class="col-sm-12">-->
<!--                                    <div class="input-group">-->
<!--                                        <input type="text" name="username"-->
<!--                                               placeholder="Enter a username to gift this package to"-->
<!--                                               class="form-control">-->
<!--                                        <div class="input-group-btn">-->
<!--                                            <button type="submit" class="btn btn-primary">Gift</button>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </form>-->
<!--                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                category: {},
                items: {},
                item: {
                    name: '',
                    price: 0.00,
                    description: ''
                }
            }
        },
        methods: {
            checkPermission() {
                if (!this.$cookie.get('token')) {
                    this.$router.push({name: 'auth'});
                }

                this.fetchData(this.$route.params.url);
            },
            async fetchData(url) {
                const response = await this.$root.axios.post(`/categories/get/${url}`);
                const data = response.data;

                this.category = data.category;
                this.items = data.items;
            },
            async showDescription(id) {
                const response = await this.$root.axios.post(`/items/get/${id}`);
                const data = response.data;

                if (data.success) {
                    this.item = data;
                    $('#popup-modal').modal('show');
                }
            },
            async addToCart(id) {
                const response = await this.$root.axios.post(`/cart/add/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} added to Cart`);
                }
            },
            async removeInCart(id) {
                const response = await this.$root.axios.post(`/cart/remove/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} remove in Cart`);
                }
            }
        },
        created() {
            this.checkPermission();
        },
        watch: {
            $route(to, from) {
                this.checkPermission();
            }
        }
    }
</script>
