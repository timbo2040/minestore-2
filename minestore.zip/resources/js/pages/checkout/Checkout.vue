<template>
    <div class="full-width">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="pull-left">
                    Checkout
                </div>
                <div class="text-right">
                    {{ $root.cart.price.toFixed(2) }} <small>USD</small>
                </div>
            </div>
            <div class="panel-body">
                <div class="checkout">
                    <div class="packages">
                        <form onsubmit="return false;">
                            <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>Name</th>
                                    <th>Package Options</th>
                                    <th>Price</th>
                                    <th class="hidden-xs">Quantity</th>
                                    <th>&nbsp;</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="item in $root.cartItems">
                                    <td class="attribute"></td>
                                    <td class="name">
                                        {{ item.name }}
                                    </td>
                                    <td class="options hidden-xs"></td>
                                    <td class="price">{{ item.price.toFixed(2) }} <small>USD</small></td>
                                    <td class="quantity"><input type="text" v-model="item.count"></td>
                                    <td class="buttons">
                                        <button class="btn btn-default btn-sm hidden-xs" @click="reloadItem(item.id, item.count)">
                                            <i class="fa fa-refresh"></i>
                                        </button>
                                        <a class="btn btn-info hidden-xs btn-sm toggle-modal"
                                           @click="showDescription(item.id)">
                                            <i class="fa fa-info-circle"></i>
                                        </a>
                                        <a class="btn btn-danger btn-sm" @click="removeInCart(item.id)">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>

                    <div class="page-header">
                        <h4>Redeem coupons or Gift cards</h4>
                    </div>

                    <div class="coupons">
                        <div class="redeem">
                            <form onsubmit="return false;" v-on:submit="submitCoupon" v-if="!couponActive">
                                <div class="input-group">
                                    <input type="text" name="coupon"
                                           placeholder="Have a coupon code? Enter it here and click &quot;redeem&quot;."
                                           class="form-control"
                                           v-model="coupon"
                                    >
                                    <div class="input-group-btn">
                                        <button :disabled="disableCouponBtn" class="btn btn-primary">Redeem <i class="fa fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <span v-else>Active coupon: {{ coupon }} ({{ couponPercent }}%)</span>
                        </div>

                        <div class="redeemed">

                        </div>
                    </div>

                    <form onsubmit="return false;" class="gateway">
                        <div class="page-header">
                            <h4>Payment method</h4>
                        </div>

                        <div class="gateways">
                            <div class="radio">
                                <label v-for="method in paymentMethods">
                                    <input type="radio" name="gateway" :checked="paymentMethod === method.name" @click="paymentMethod = method.name">
                                    {{ method.name }}
                                </label>
                            </div>
                        </div>

                        <div class="tax" style="display: none;"></div>
                        <div class="privacyStatement">
                            <div class="page-header">
                                <h4>Privacy Statement</h4>
                            </div>
                            <p>
                                <input type="checkbox" name="privacyConsent" id="privacyConsent" value="1" v-model="privacy">
                                <label for="privacyConsent" class="form__choice"
                                       style="display:inline;font-weight:normal;font-size:14px;">
                                    We take your privacy seriously. We collect data to process your order and to provide
                                    updates about our network in line with our <a class="toggle-modal" @click="openPrivacy">Privacy
                                    Policy</a>. By ticking this box you confirm you are over 16 years of age or have the
                                    permission of your guardian, and consent to us processing your data in this way.
                                </label>
                            </p>
                            <br>
                        </div>

                        <div class="page-header">
                            <h4>Purchase </h4>
                        </div>

                        <div class="row">
                            <div class="col-sm-8">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value="true" name="agreement" v-model="terms">
                                        I agree to the <a class="toggle-modal" @click="openTerms">terms
                                        &amp; conditions</a> of this purchase.
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <button type="submit" :disabled="disableButton" class="btn btn-success btn-block" id="purchase-button" @click="purchase"
                                    >Purchase »
                                    </button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="modal" id="popup-modal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title">{{ item.name }}</h4>
                    </div>
                    <div class="modal-body" v-html="item.description">

                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-4">
                                <p class="pull-left">
                                    <b>{{ item.price.toFixed(2) }} <small>USD</small></b>
                                </p>
                            </div>
                            <div class="col-sm-8">
                                <div style="display: inline-block;" class="package-footer-buttons">
                                    <a class="btn btn-success gift-weight" v-if="!item.in_cart"
                                       @click="addToCart(item.id)">Add to cart</a>
                                    <a class="btn btn-danger gift-weight" v-if="item.in_cart"
                                       @click="removeInCart(item.id)">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal" id="privacy" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true"><div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Terms and conditions</h4>
                </div>
                <div class="modal-body">
                    <p>
                    </p><h1>PRIVACY NOTICE – YOURSTORE LIMITED</h1>
                    <h2>INTRODUCTION</h2>                    <p>

                    </p>


                    <p></p>
                </div>
            </div>
        </div></div>
        <div class="modal" id="terms" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true"><div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Terms and conditions</h4>
                </div>
                <div class="modal-body">
                    <p>
                    </p><p><span style="color:#000000;"><strong>Last Modified On: Friday, March 21, 2020</strong></span></p>
                    <p>&nbsp;</p>
                    <p><span style="color:#000000;"><strong>1. These Terms and Conditions form legally binding contracts between you and YOURSTORE. By playing on YOURSTORE and purchasing at the server you affirm that you are at least 18 years of age (or have reached the age of majority if that is not 18 years of age where you live) or that you have reviewed this Agreement with your parent or guardian and he or she assents to these Terms of Service on your behalf and takes full responsibility for your compliance with them. You agree that you and/or your parent or guardian are fully able and competent to enter into the terms, conditions, obligations, representations, and responsibilities set forth in these Terms of Service, and to abide and comply with these Terms of Service. Please note you agree to these Terms and Conditions by making a purchase to YOURSTORE. &nbsp;</strong></span></p>
                    <p>&nbsp;</p>
                    <p><span style="color:#000000;"><strong>2. By transferring money or monies to YOURSTORE you agree that your purchase will only be refunded if the service is not used to any extent and that no other refunds shall be granted. You also agree that any notification of a chargeback or dispute will be considered as strong evidence of fraud occurring on your account and we may close or block your account from accessing our services.</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>3. You agree to indemnify the staff, owners, hosts, advertisers, officers, directors, employees, partners, and all other parties related to the server. By agreeing to these terms, you agree not to present any lawsuit or other legal challenges against the server staff for any reason, whether related to your purchase or not. &nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>4. You understand and agree that your use of this website and any services or content provided is made available and provided to you at your own risk. It is provided to you as-is and we expressly disclaim all warranties of any kind, expressed or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and non-infringement. You understand and agree that neither us nor any participant in the service provides professional advice of any kind and thus use of such advice or any other information is solely at your own risk and without our liability of any kind. Some jurisdictions may not allow disclaimers of implied warranties and the above disclaimer may not apply to you only as it relates to implied warranties. &nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>5. YOURSTORE accepts players purchasing on behalf of another player. You agree you will not chargeback or dispute a payment made for another person in any event or under any circumstances</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>6. You agree to take full responsibility for your purchase. Players who violate these Terms and Conditions or any other player rules on our server may have their accessed removed at any time without warning. &nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>7. You expressly understand and agree that we shall not be liable for any direct, indirect, special, incidental, consequential or exemplary damages, including but not limited to, damages for loss of profits, goodwill, use, data or other intangible loss (even if we have been advised of the possibility of such damages), resulting from or arising out of: (I) The use of or the inability to use the service, (II) The cost to obtain substitute goods and/or services resulting from any transaction entered into on trough the service, (III) Unauthorized access to or alternation of your data transmissions, (IV) Statements or conduct of any third party on the service, or (V) any other matter relating to the service. Note that by accepting the terms in the document, you are also waiving your right, to take any action, legal or otherwise, against anyone or anything related to the staff, management, administrators, members, owners or any hosts of this server. You furthermore acknowledge that if any part of this document is found to be invalid or unenforceable in any way, any parts not found to be invalid or unenforceable will be considered fully valid and binding. &nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>&nbsp;</strong></span></p>
                    <p><span style="color:#000000;"><strong>8. All terms and conditions are in effect indefinitely as soon as the contract is accepted, and will remain to be active even after you quit, are banished, removed, or if you leave the server/forum in any way. Refund Policy: All sales are final, you may not buyback, stop, credit the server by any means necessary in order to receive your funds back that of which have been paid. And in doing so we reserve the right to disallow your continued play on the server/forums and not allow further funds to be added or taken away. We reserve the right to pursue any legal or collection action necessary to recover damages in the event of a forced charge-back.&nbsp;</strong></span></p>
                    <p></p>
                </div>
            </div>
        </div></div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                item: {
                    name: '',
                    price: 0.00,
                    description: ''
                },
                privacy: false,
                terms: false,
                paymentMethod: 'PayPal',
                paymentMethods: {},
                disableButton: false,
                coupon: '',
                couponPercent: 0,
                couponActive: false,
                disableCouponBtn: false
            }
        },
        methods: {
            async showDescription(id) {
                const response = await this.$root.axios.post(`/items/get/${id}`);
                const data = response.data;

                if (data.success) {
                    this.item = data;
                    $('#popup-modal').modal('show');
                }
            },
            async removeInCart(id) {
                const response = await this.$root.axios.post(`/cart/remove/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} remove in Cart`);

                    if (this.$root.cart.items === 0) {
                        this.$router.push({name: 'index'});
                    }
                }
            },
            async reloadItem(id, count) {
                const response = await this.$root.axios.post(`/cart/reload/${id}`, {
                    count: count
                });
                const data = response.data;

                if (data.success) {
                    await this.$root.getCart();

                    if (this.$root.cart.items === 0) {
                        this.$router.push({name: 'index'});
                    }
                }
            },
            openTerms() {
                $('#terms').modal('show');
            },
            openPrivacy() {
                $('#privacy').modal('show');
            },
            async purchase() {
                this.disableButton = true;

                if (!this.privacy) {
                    this.disableButton = false;
                    return this.$root.showNotification('error', `Accept Privacy Statement`);
                }

                if (!this.terms) {
                    this.disableButton = false;
                    return this.$root.showNotification('error', `Accept Terms`);
                }

                const response = await this.$root.axios.post(`/payments/create`, {
                    paymentMethod: this.paymentMethod
                });
                const data = response.data;

                if (data.success) {
                    if (data.data !== null && typeof data.data.url !== "undefined") {
                        if (data.data.type === 'url') {
                            window.location.href = data.data.url;
                        } else {
                            const block = $(data.data.html);
                            $(document.body).append(block);
                            block.submit();
                        }
                    } else {
                        this.disableButton = false;
                        return this.$root.showNotification('error', 'Error generating payment link');
                    }
                } else {
                    this.disableButton = false;
                    return this.$root.showNotification('error', data.message);
                }
            },
            async getPaymentMethods() {
                const response = await this.$root.axios.post(`/payments/get`);

                this.paymentMethods = response.data;
            },
            async submitCoupon() {
                if (this.disableCouponBtn) {
                    return false;
                }

                this.disableCouponBtn = true;

                const response = await this.$root.axios.post(`/cart/acceptCoupon`, {
                    coupon: this.coupon
                });
                const data = response.data;

                if (data.success) {
                    await this.$root.getCart();

                    this.$root.showNotification('success', data.message);

                    if (data.type === 'coupon') {
                        this.couponPercent = data.percent;
                        this.couponActive = true;
                    } else {
                        this.disableCouponBtn = false;
                    }
                } else {
                    this.disableCouponBtn = false;
                    this.$root.showNotification('error', data.message);
                }
            },
            async getCoupon() {
                const response = await this.$root.axios.post(`/cart/getCoupon`);
                const data = response.data;

                if (data.coupon !== '') {
                    this.coupon = data.coupon;
                    this.couponPercent = data.percent;
                    this.couponActive = true;
                    this.disableCouponBtn = true;
                }
            }
        },
        mounted() {
            if (!this.$cookie.get('token')) {
                this.$router.push({name: 'auth'});
            }

            this.getPaymentMethods();
            this.getCoupon();

            setTimeout(() => {
                if (this.$root.cart.items === 0) {
                    this.$router.go(-1);
                }
            }, 500);
        }
    }
</script>
