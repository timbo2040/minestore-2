<template>
    <div class="panel panel-default panel-mstr-home">

        <div id="mstr-home">
            <div class="home-header">
                <div class="home-title">
                    <span class="small">WELCOME TO THE</span>
                    <span class="big">{{ $root.settings.website_name }}</span>
                </div>
                <div class="home-package" v-if="$root.settings.deal">
                    <div class="text">
                        <span class="name">{{ $root.settings.deal.name }}</span>
                        <div class="price">
                            <div class="price-compare">
                                <span class="old" v-if="$root.settings.deal.discount> 0">{{ $root.settings.deal.discount }} USD</span>
                                <span class="current">{{ $root.settings.deal.price }} USD</span>
                            </div>
                            <button class="btn btn-info toggle-modal" @click="showDescription($root.settings.deal.id)">INFO</button>
                        </div>
                    </div>
                    <div class="image toggle-tooltip toggle-modal" title="" @click="showDescription($root.settings.deal.id)"
                         data-original-title="Click for more info">
                        <img
                            :src="$root.settings.deal.image"
                            alt="Package Icon">
                    </div>
                </div>
            </div>
            <hr>
            <div v-html="$root.settings.content"></div>
        </div>
        <div class="modal" id="popup-modal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title">{{ item.name }}</h4>
                    </div>
                    <div class="modal-body" v-html="item.description">

                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-sm-4">
                                <p class="pull-left">
                                    <b>{{ item.price.toFixed(2) }} <small>USD</small></b>
                                </p>
                            </div>
                            <div class="col-sm-8">
                                <div style="display: inline-block;" class="package-footer-buttons" v-if="$root.user !== null">
                                    <a class="btn btn-success gift-weight" v-if="!item.in_cart" @click="addToCart(item.id)">Add to cart</a>
                                    <a class="btn btn-danger gift-weight" v-if="item.in_cart" @click="removeInCart(item.id)">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                item: {
                    name: '',
                    price: 0.00,
                    description: ''
                }
            }
        },
        methods: {
            async showDescription(id) {
                let response;

                if (this.$root.user !== null) {
                    response = await this.$root.axios.post(`/items/get/${id}`);
                } else {
                    response = await this.$root.axios.post(`/items/get/guest/${id}`);
                }

                const data = response.data;

                if (data.success) {
                    this.item = data;
                    $('#popup-modal').modal('show');
                }
            },
            async addToCart(id) {
                const response = await this.$root.axios.post(`/cart/add/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} added to Cart`);
                }
            },
            async removeInCart(id) {
                const response = await this.$root.axios.post(`/cart/remove/${id}`);
                const data = response.data;

                if (data.success) {
                    $('#popup-modal').modal('hide');
                    await this.$root.getCart();
                    this.$root.showNotification('success', `Item ${this.item.name} remove in Cart`);
                }
            }
        }
    }
</script>
