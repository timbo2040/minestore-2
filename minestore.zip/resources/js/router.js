import Vue from 'vue';
import VueRouter from 'vue-router';
import Index from "./pages/index/Index";
import Category from "./pages/category/Category";
import Auth from "./pages/auth/Auth";
import Callback from "./pages/auth/Callback";
import Checkout from "./pages/сheckout/Checkout";
import Page from "./pages/custom/Page";

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component: Index
        },
        {
            path: '/category/:url',
            name: 'category',
            component: Category
        },
        {
            path: '/auth',
            name: 'auth',
            component: Auth
        },
        {
            path: '/auth/callback',
            name: 'auth.callback',
            component: Callback
        },
        {
            path: '/checkout',
            name: 'checkout',
            component: Checkout
        },
        {
            path: '/c/:url',
            name: 'custom',
            component: Page
        },
        {
            path: '*',
            redirect: '/'
        }
    ]
})
