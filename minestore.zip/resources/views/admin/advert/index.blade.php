@extends('admin.layout')

@section('content')
    <form class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Announcement</h4>
        </div>
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="title" class="control-label">Title</label>
                <input type="text" id="title" name="title" class="form-control" value="{{ $advert->title }}">
            </div>
            <div class="form-group label-floating">
                <textarea id="text" name="content" class="form-control">{{ $advert->content }}</textarea>
            </div>
            <div class="form-group label-floating">
                <label for="button_name" class="control-label">Button name</label>
                <input type="text" id="button_name" name="button_name" class="form-control" value="{{ $advert->button_name }}">
            </div>
            <div class="form-group label-floating">
                <label for="button_href" class="control-label">Link for button</label>
                <input type="text" id="button_url" name="button_url" class="form-control" value="{{ $advert->button_url }}">
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
        </div>
    </form>
    <script src="//cdn.ckeditor.com/4.6.2/full/ckeditor.js"></script>
    <script type="text/javascript">
        window.onload = function () {
            CKEDITOR.replace('content');
        }
    </script>
@endsection
