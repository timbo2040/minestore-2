<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Authorization - Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="mobile-web-app-capable" content="yes">
    <link href="{{ asset('style/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('style/css/material-dashboard.css') }}" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
</head>

<body>
<div class="container" style="margin-top: 10%;">
    <div class="content">
        <div class="container-fluid col-md-4 col-md-offset-4">
            <div class="card">
                <div class="card-header card-header-icon" data-background-color="green">
                    <i class="material-icons">contacts</i>
                </div>
                <div class="card-content">
                    <h4 class="card-title">Authorization</h4>
                    <form id="auth" action="/admin/login" method="POST">
                        <div class="form-group label-floating">
                            <label for="login" class="control-label">Login:</label>
                            <input id="login" name="login" type="text" class="form-control" maxlength="20" required>
                        </div>
                        <div class="form-group label-floating">
                            <label for="password" class="control-label">Password:</label>
                            <input autocomplete="off" id="password" name="password" type="password" class="form-control" maxlength="50" required>
                        </div>
                        <button type="submit" class="btn btn-block btn-success">Sign in</button>
                    </form>
                    <div class="text-center">
                        <hr>
                        &copy; MINESTORE. Script by <a target="_blank">JordyDeveloper</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>

<script src="{{ asset('style/js/jquery-3.1.1.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/material.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/perfect-scrollbar.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('style/js/jquery.select-bootstrap.js') }}"></script>
<script src="{{ asset('style/js/material-dashboard.js') }}"></script>
<script type="text/javascript">
    function setFormValidation(id) {
        $(id).validate({
            errorPlacement: function(error, element) {
                $(element).parent('div').addClass('has-error');
            }
        });
    }

    $(document).ready(function() {
        setFormValidation('#auth');
    });
</script>
</html>
