@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="title" class="control-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ $category->name }}" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="top_category_id" class="control-label">Top category</label>
                <select id="top_category_id" name="top_category_id" class="selectpicker" data-style="select-with-transition" title="Select a top category" data-size="7" required>
                    <option disabled> Select a category</option>
                    @foreach ($topCategories as $topCategory)
                        <option @if($category->top_category_id === $topCategory->id) selected @endif value="{{ $topCategory->id }}">{{ $topCategory->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group label-floating">
                <label for="title" class="control-label">Url</label>
                <input type="text" id="url" name="url" class="form-control" value="{{ $category->url }}" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="priority" class="control-label">Priority view</label>
                <input type="number" id="sorting" name="sorting" class="form-control" value="{{ $category->sorting }}">
                <span class="material-input"></span>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>
@endsection
