@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Category list</h4>
        </div>
        <div class="card-content">
            <a href="{{ route('categories_new') }}" class="btn btn-block btn-danger"><i class="material-icons">add</i> Add
                category
                <div class="ripple-container"></div>
            </a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Top category</th>
                        <th>Priority</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($categories as $category)
                        <tr>
                            <td>{{ $category->id }}</td>
                            <td>{{ $category->name }}</td>
                            <td><a href="{{ route('top_categories_c', ['id' => $category->TopCategory->id]) }}">{{ $category->TopCategory->name }}</a></td>
                            <td>{{ $category->sorting }}</td>
                            <td class="td-actions">
                                <a href="{{ route('categories_c', ['id' => $category->id]) }}" rel="tooltip" class="btn btn-info btn-simple"
                                   data-original-title="Edit"><i class="material-icons">edit</i></a>
                                <a href="{{ route('categories_delete', ['id' => $category->id])  }}" rel="tooltip"
                                   class="btn btn-danger btn-simple" data-original-title="Delete"><i class="material-icons">close</i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
