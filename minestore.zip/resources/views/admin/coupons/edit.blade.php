@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="title" class="control-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ $coupon->name }}" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="discount" class="control-label">Discount (%)</label>
                <input type="number" id="discount" name="discount" class="form-control" value="{{ $coupon->discount }}" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="available" class="control-label">Number of avaliable uses</label>
                <input type="number" id="available" name="available" class="form-control" value="{{ $coupon->available }}">
                <span class="material-input"></span>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>
@endsection
