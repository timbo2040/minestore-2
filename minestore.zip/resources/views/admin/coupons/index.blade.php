@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Coupons list</h4>
        </div>
        <div class="card-content">
            <a href="{{ route('coupons_new') }}" class="btn btn-block btn-danger"><i class="material-icons">add</i> Add
                coupon
                <div class="ripple-container"></div>
            </a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Discount (%)</th>
                        <th>Usage remaining	</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($coupons as $coupon)
                        <tr>
                            <td>{{ $coupon->id }}</td>
                            <td>{{ $coupon->name }}</td>
                            <td>{{ $coupon->discount }}</td>
                            <td>{{ $coupon->available }}</td>
                            <td class="td-actions">
                                <a href="{{ route('coupons_c', ['id' => $coupon->id]) }}" rel="tooltip" class="btn btn-info btn-simple"
                                   data-original-title="Edit"><i class="material-icons">edit</i></a>
                                <a href="{{ route('coupons_delete', ['id' => $coupon->id])  }}" rel="tooltip"
                                   class="btn btn-danger btn-simple" data-original-title="Delete"><i class="material-icons">close</i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
