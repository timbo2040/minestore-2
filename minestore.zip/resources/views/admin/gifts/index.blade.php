@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Gifts list</h4>
        </div>
        <div class="card-content">
            <a href="{{ route('gifts_new') }}" class="btn btn-block btn-danger"><i class="material-icons">add</i> Add
                gift
                <div class="ripple-container"></div>
            </a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Start Balance</th>
                        <th>End Balance</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($gifts as $gift)
                        <tr>
                            <td>{{ $gift->id }}</td>
                            <td>{{ $gift->name }}</td>
                            <td>{{ $gift->start_balance }}</td>
                            <td>{{ $gift->end_balance }}</td>
                            <td class="td-actions">
                                <a href="{{ route('gifts_c', ['id' => $gift->id]) }}" rel="tooltip" class="btn btn-info btn-simple"
                                   data-original-title="Edit"><i class="material-icons">edit</i></a>
                                <a href="{{ route('gifts_delete', ['id' => $gift->id])  }}" rel="tooltip"
                                   class="btn btn-danger btn-simple" data-original-title="Delete"><i class="material-icons">close</i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
