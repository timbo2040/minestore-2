@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating is-empty">
                <label for="title" class="control-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="title" class="control-label">Image</label>
                <input type="text" id="image" name="image" class="form-control" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating is-empty">
                <label for="title" class="control-label">Price</label>
                <input type="number" id="price" name="price" class="form-control" value="" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="title" class="control-label">Discount (%)</label>
                <input type="number" id="discount" name="discount" class="form-control" value="0" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating is-empty">
                <textarea type="text" id="description" name="description" class="form-control" required></textarea>
            </div>
            <div class="form-group label-floating is-empty">
                <label for="priority" class="control-label">Priority view</label>
                <input type="number" id="sorting" name="sorting" class="form-control" value="">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="category_url" class="control-label">Category</label>
                <select id="category_url" name="category_url" class="selectpicker" data-style="select-with-transition" title="Select a category" data-size="7" required>
                    <option disabled> Select a category</option>
                    @foreach ($topCategories as $category)
                        <option value="{{ $category->url }}">{{ $category->name }}</option>
                    @endforeach
                    @foreach ($categories as $category)
                        <option value="{{ $category->url }}">{{ $category->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group label-floating">
                <label for="server_id" class="control-label">Server</label>
                <select id="server_id" name="server_id" class="selectpicker" data-style="select-with-transition" title="Select a server" data-size="7" required>
                    <option disabled> Select a server</option>
                    <option value="NULL">All servers</option>
                    @foreach ($servers as $server)
                        <option value="{{ $server->id }}">{{ $server->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="commands" class="control-label">Commands for delivery:</label>
                <button type="button" class="btn btn-primary btn-block" onclick="add()"><i class="material-icons">add</i> Add </button>
                <hr>
                <div class="commands">

                </div>
                <code>{user} - The username of the player that donated. (Variable)</code>
                <hr>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>

    <script type="text/javascript">
        var id = 0;
        function add() {
            id++;
            var clearinput = '<div class="command" id="command_' + id + '"><div class="input-group form-group label-floating is-empty"><label for="command_c_' + id + '" class="control-label">Command</label><input type="text" name="command[' + id + ']" class="form-control" required><span class="input-group-btn"><button type="button" onclick="removeid(' + id + ')" class="btn btn-warning btn-round"><i class="material-icons">delete</i></button></span><span class="material-input"></span></div></div>';
            $('.commands').append(clearinput);
            $('#command_' + id).hide();
            $('#command_' + id).fadeIn();
        }
        function removeid(blockid) {
            if (blockid == id) { id--; }
            $('#command_' + blockid).fadeOut(function(){$(this).remove()})
        }
    </script>

    <script src="//cdn.ckeditor.com/4.6.2/full/ckeditor.js"></script>
    <script type="text/javascript">
        window.onload = function () {
            CKEDITOR.replace('description');
        }
    </script>
@endsection
