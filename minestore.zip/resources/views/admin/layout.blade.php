    <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="mobile-web-app-capable" content="yes">
    <link href="{{ asset('style/css/bootstrap2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('style/css/material-dashboard.css') }}" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
</head>

<body>
<div class="wrapper">
    <div class="sidebar" data-active-color="red" data-background-color="black">
        <div class="logo">
            <a href="/" rel="tooltip" data-placement="bottom" class="simple-text">
                MINESTORE				</a>
        </div>
        <div class="sidebar-wrapper">
            <ul class="nav">
                <li class="{{ (\Request::route()->getName() === 'index' ? 'active' : '') }}">
                    <a href="{{ route('index') }}">
                        <i class="material-icons">dashboard</i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'top_categories') !== false ? 'active' : '') }}">
                    <a href="{{ route('top_categories') }}">
                        <i class="material-icons">category</i>
                        <p>Top categories</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'categories') !== false && strrpos(\Request::route()->getName(), 'top_categories') === false ? 'active' : '') }}">
                    <a href="{{ route('categories') }}">
                        <i class="material-icons">category</i>
                        <p>Categories</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'goods') !== false ? 'active' : '') }}">
                    <a href="{{ route('goods') }}">
                        <i class="material-icons">reorder</i>
                        <p>Packages</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'coupons') !== false ? 'active' : '') }}">
                    <a href="{{ route('coupons') }}">
                        <i class="material-icons">card_giftcard</i>
                        <p>Coupons</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'gifts') !== false ? 'active' : '') }}">
                    <a href="{{ route('gifts') }}">
                        <i class="material-icons">card_giftcard</i>
                        <p>Gifts</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'pages') !== false ? 'active' : '') }}">
                    <a href="{{ route('pages') }}">
                        <i class="material-icons">pages</i>
                        <p>Pages</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'payments') !== false ? 'active' : '') }}">
                    <a href="{{ route('payments') }}">
                        <i class="material-icons">receipt</i>
                        <p>Payments</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'rcon') !== false ? 'active' : '') }}">
                    <a href="{{ route('rcon') }}">
                        <i class="material-icons">developer_board</i>
                        <p>Remote console (RCON)</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'users') !== false ? 'active' : '') }}">
                    <a href="{{ route('users') }}">
                        <i class="material-icons">account_circle</i>
                        <p>Users</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'advert') !== false ? 'active' : '') }}">
                    <a href="{{ route('advert') }}">
                        <i class="material-icons">rss_feed</i>
                        <p>Announcement</p>
                    </a>
                </li>
                <li class="{{ (strrpos(\Request::route()->getName(), 'settings') !== false ? 'active' : '') }}">
                    <a data-toggle="collapse" href="#settings" aria-expanded="false" class="collapsed">
                        <i class="material-icons">settings</i>
                        <p>Settings
                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse" id="settings">
                        <ul class="nav">
                            <li class="{{ (\Request::route()->getName() === 'settings' ? 'active' : '') }}">
                                <a href="{{ route('settings') }}">
                                    Main settings
                                </a>
                            </li>
                            <li class="{{ (\Request::route()->getName() === 'settings_merchant' ? 'active' : '') }}">
                                <a href="{{ route('settings_merchant') }}">
                                    Payment methods
                                </a>
                            </li>
                            <li class="{{ (\Request::route()->getName() === 'settings_discord' ? 'active' : '') }}">
                                <a href="{{ route('settings_discord') }}">
                                    Discord notifications
                                </a>
                            </li>
                            <li class="{{ (\Request::route()->getName() === 'settings_links' ? 'active' : '') }}">
                                <a href="{{ route('settings_links') }}">
                                    Link settings
                                </a>
                            </li>
                            <li class="{{ (\Request::route()->getName() === 'settings_servers' ? 'active' : '') }}">
                                <a href="{{ route('settings_servers') }}">
                                    Servers
                                </a>
                            </li>
                            <li class="{{ (\Request::route()->getName() === 'settings_main' ? 'active' : '') }}">
                                <a href="{{ route('settings_main') }}">
                                    Index page
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-transparent navbar-absolute">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Open menu</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand hidden-xs">Dashboard :: {{ $title }}</a>
                    <a class="navbar-brand visible-xs">Dashboard :: {{ $title }}</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="material-icons">person</i>
                                <p class="hidden-lg hidden-md">
                                    User
                                    <b class="caret"></b>
                                </p>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="admin/logout">Logout</a>
                                </li>
                            </ul>
                        </li>
                        <li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="container-fluid">
                @yield('content')
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="/">
                                Back on site
                            </a>
                        </li>
                        <li>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    JordyDeveloper &copy;
                    <script>
                        document.write(new Date().getFullYear())
                    </script>
                </p>
            </div>
        </footer>
    </div>
</div>
</body>

<script src="{{ asset('style/js/jquery-3.1.1.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/material.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/perfect-scrollbar.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('style/js/jquery.datatables.js') }}"></script>
<script src="{{ asset('style/js/jquery.select-bootstrap.js') }}"></script>
<script src="{{ asset('style/js/jasny-bootstrap.min.js') }}"></script>
<script src="{{ asset('style/js/material-dashboard.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.card .material-datatables label').addClass('form-group');
    });
    function setFormValidation(id) {
        $(id).validate({
            errorPlacement: function(error, element) {
                $(element).parent('div').addClass('has-error');
            }
        });
    }

    $(document).ready(function() {
        setFormValidation('#category');
        setFormValidation('#goods');
        setFormValidation('#cupons');
        setFormValidation('#users');
        setFormValidation('#settings');
        setFormValidation('#linkss');
        setFormValidation('#rcon');
    });
</script>
</html>
