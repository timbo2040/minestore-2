@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Pages list</h4>
        </div>
        <div class="card-content">
            <a href="{{ route('pages_new') }}" class="btn btn-block btn-danger"><i class="material-icons">add</i> Add
                page
                <div class="ripple-container"></div>
            </a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Page</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($pages as $page)
                        <tr>
                            <td>{{ $page->id }}</td>
                            <td><a href="/c/{{ $page->url }}">{{ $page->url }}</a></td>
                            <td>{{ $page->name }}</td>
                            <td class="td-actions">
                                <a href="{{ route('pages_c', ['id' => $page->id]) }}" rel="tooltip" class="btn btn-info btn-simple"
                                   data-original-title="Edit"><i class="material-icons">edit</i></a>
                                <a href="{{ route('pages_delete', ['id' => $page->id])  }}" rel="tooltip"
                                   class="btn btn-danger btn-simple" data-original-title="Delete"><i class="material-icons">close</i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
