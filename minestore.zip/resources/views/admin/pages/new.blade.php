@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating is-empty">
                <label for="title" class="control-label">Url</label>
                <input type="text" id="url" name="url" class="form-control" value="" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="title" class="control-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating is-empty">
                <textarea type="text" id="content" name="content" class="form-control" required></textarea>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>

    <script src="//cdn.ckeditor.com/4.6.2/full/ckeditor.js"></script>
    <script type="text/javascript">
        window.onload = function () {
            CKEDITOR.replace('content');
        }
    </script>
@endsection
