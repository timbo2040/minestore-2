@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Information about payment</h4>
        </div>
        <div class="card-content">
            <p><b>Status:</b>
                @if ($payment->status === \App\Payment::PAID)
                    <span style="color: #4CAF50; font-weight: bold;">Paid</span>
                @elseif($payment->status === \App\Payment::ERROR)
                    <span style="color: #FF5722; font-weight: bold;">Error while issuing!</span>
                @else
                    <span style="color: #FF9800;">Pending</span>
                @endif
            </p>
            <p><b>Time:</b> {{ $payment->updated_at }}</p>
            <p><b>Price:</b> {{ $payment->cart->price }} $</p>
            <hr>
            <p><b>Username:</b> {{ $payment->user->username }}</p>

            <hr>
            <b>Items:</b>
            <hr>
            @foreach($items as $item)
                <?php
                    if ($item->item->server_id === NULL) {
                        $serverName = 'All servers';
                    } else {
                        $serverName = \App\Server::query()->find($item->item->server_id)->first()->name;
                    }
                ?>
                <p><b>Package:</b> {{ $item->item->name }} (ID: {{ $item->item->id }}) ({{ $item->count }} count.)</p>
                <p><b>Server:</b> {{ $serverName }}</p>
                <p><b>Package price:</b> {{ $item->item->price }} $</p>
                <hr>
            @endforeach

            @if($payment->cart->coupon_id > 0 && $coupon = \App\Coupon::query()->find($payment->cart->coupon_id))
                <p><b>Coupon:</b> {{ $coupon->name }}</p>
                <p><b>Discount:</b> {{ $coupon->discount }}%</p>
            @endif

            <hr>
            <p>
                <a href="{{ route('payments_delivery', ['id' => $payment->id]) }}" class="btn btn-block btn-danger">
                    Delivery
                </a>
            </p>
        </div>
    </div>
@endsection
