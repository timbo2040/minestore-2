@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Payments list</h4>
        </div>
        <div class="card-content">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Username</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($payments as $payment)
                        <tr>
                            <td>{{ $payment->id }}</td>
                            <td>{{ $payment->user->username }}</td>
                            <td>{{ $payment->updated_at }}</td>
                            <td>
                                @if ($payment->status === \App\Payment::PAID)
                                    <span style="color: #4CAF50; font-weight: bold;">Paid</span>
                                @elseif($payment->status === \App\Payment::ERROR)
                                    <span style="color: #FF5722; font-weight: bold;">Error while issuing!</span>
                                @else
                                    <span style="color: #FF9800;">Pending</span>
                                @endif
                            </td>
                            <td class="">
                                <a href="{{ route('payments_c', ['id' => $payment->id]) }}" rel="tooltip" class="btn btn-info btn-simple btn-icon" data-original-title="View">
                                    <i class="material-icons">visibility</i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <br>
            <div class="text-center">
                <div class="btn-group" role="group">
                    {{ $payments->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection
