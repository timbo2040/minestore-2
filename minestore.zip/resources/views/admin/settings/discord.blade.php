@extends('admin.layout')

@section('content')
    <form id="linkss" class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Notification about payments</h4>
        </div>
        <div class="card-content">
            <div class="form-group">
                <div class="text">You can find it here: "Go to your discord server -> Server Settings -> Webhooks -> Create Webhook" and put URL.</div>
                <label for="accessToken" class="control-label">Discord Webhook URL</label>
                <input type="text" id="webhook_url" name="webhook_url" value="{{ $settings->webhook_url }}" class="form-control" placeholder="Webhook URL" required>
            </div>
            <div class="form-group">
                <label for="accessToken" class="control-label">Discord Guild ID</label>
                <input type="text" id="discord_guild_id" name="discord_guild_id" value="{{ $settings->discord_guild_id }}" class="form-control" placeholder="Discord Guild ID" required>
            </div>
            <div class="form-group">
                <label for="accessToken" class="control-label">Discord URL</label>
                <input type="text" id="discord_url" name="discord_url" value="{{ $settings->discord_url }}" class="form-control" placeholder="Discord URL" required>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
        </div>
    </form>
@endsection
