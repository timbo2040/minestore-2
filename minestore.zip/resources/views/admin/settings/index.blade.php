@extends('admin.layout')

@section('content')
    <form id="settings" class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Main settings</h4>
        </div>
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="site_name" class="control-label">Website name</label>
                <input name="site_name" class="form-control" id="site_name" type="text" value="{{ $settings->site_name }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="serverIP" class="control-label">Server IP</label>
                <input name="serverIP" class="form-control" id="serverIP" type="text" value="{{ $settings->serverIP }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="serverPort" class="control-label">Server Port</label>
                <input name="serverPort" class="form-control" id="serverPort" type="text"value="{{ $settings->serverPort }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="withdraw" class="control-label">Withdraw type:</label>
                <select id="withdraw_type" name="withdraw_type" class="selectpicker" data-style="select-with-transition" title="Select delivery method" data-size="7" required>
                    <option disabled>Select delivery method:
                    <option @if($settings->withdraw_type === 'rcon') selected @endif value="rcon">RCON</option>
                    <option @if($settings->withdraw_type === 'plugin') selected @endif value="plugin">Plugin</option>
                </select>
            </div>
            <div class="form-group label-floating">
                <label for="withdraw" class="control-label">Withdraw game:</label>
                <select id="withdraw_game" name="withdraw_game" class="selectpicker" data-style="select-with-transition" title="Select game" data-size="7" required>
                    <option disabled>Select game:
                    <option @if($settings->withdraw_game === 'minecraft') selected @endif value="minecraft">Minecraft</option>
                    <option @if($settings->withdraw_game === 'unturned') selected @endif value="unturned">Unturned</option>
                </select>
            </div>
            <div class="form-group label-floating">
                <label for="withdraw" class="control-label">Auth type:</label>
                <select id="auth" name="auth" class="selectpicker" data-style="select-with-transition" title="Select auth method" data-size="7" required>
                    <option disabled>Select auth method:
                    <option @if($settings->auth === 'username') selected @endif value="username">Username</option>
                    <option @if($settings->auth === 'steamid') selected @endif value="steamid">Steam</option>
                </select>
            </div>
            <hr>
            <h4 class="title">MySQL Settings</h4>
            <div class="form-group label-floating">
                <label for="db_host" class="control-label">MySQL DB Host</label>
                <input name="DB_HOST" class="form-control" id="DB_HOST" type="text" value="{{ $database['DB_HOST'] }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="db_port" class="control-label">MySQL DB Port</label>
                <input name="DB_PORT" class="form-control" id="DB_PORT" type="text" value="{{ $database['DB_PORT'] }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="db_name" class="control-label">MySQL DB Name</label>
                <input name="DB_DATABASE" class="form-control" id="DB_DATABASE" type="text" value="{{ $database['DB_DATABASE'] }}" required>
            </div>
            <div class="form-group label-floating">
                <label for="db_user" class="control-label">MySQL DB User</label>
                <input name="DB_USERNAME" class="form-control" id="DB_USERNAME" type="text" value="{{ $database['DB_USERNAME'] }}" required>
            </div>
            <div class="form-group">
                <label for="db_pass" class="control-label">MySQL DB Password</label>
                <input name="DB_PASSWORD" class="form-control" id="DB_PASSWORD" type="text" placeholder="HIDDEN">
                <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
            </div>
    </form>
@endsection
