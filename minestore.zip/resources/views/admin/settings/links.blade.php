@extends('admin.layout')

@section('content')
    <form id="linkss" class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Link settings</h4>
        </div>
        <div class="card-content">
            <button class="btn btn-primary btn-block" type="button" onclick="add()"><i class="material-icons">add</i>
                Add
            </button>
            <hr>
            <div id="links" class="form-group">
                <?php $i = 0; ?>
                @foreach($links as $link)
                    <div class="row" id="links[{{ $i }}]">
                        <div class="col-xs-6 col-sm-5">
                            <div class="form-group label-floating">
                                <label for="links[{{ $i }}][name]" class="control-label">Name</label>
                                <input name="links[{{ $i }}][name]" class="form-control" type="text"
                                       value="{{ $link->name }}" required>
                            </div>
                        </div>
                        <div class="col-xs-6 col-sm-5">
                            <div class="form-group label-floating">
                                <label for="links[{{ $i }}][url]" class="control-label">Link</label>
                                <input name="links[{{ $i }}][url]" class="form-control" type="text"
                                       value="{{ $link->url }}" required>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-2 text-center">
                            <button class="btn btn-warning btn-round" type="button" onclick="removeid('{{ $i }}')"><i
                                    class="material-icons">delete</i></button>
                        </div>
                        <div class="col-xs-5 form-group" style="padding-bottom: 0px; margin: 0px;">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"
                                           name="links[{{ $i }}][footer]" @if($link->type == \App\Link::SHOW_FOOTER || $link->type == \App\Link::SHOW_ALL) checked @endif>
                                    Show in Footer?
                                </label>
                            </div>
                        </div>
                        <div class="col-xs-7 form-group" style="padding-bottom: 0px; margin: 0px;">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"
                                           name="links[{{ $i }}][header]" @if($link->type == \App\Link::SHOW_HEADER || $link->type == \App\Link::SHOW_ALL) checked @endif>
                                    Show in Header?
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php $i++ ?>
                @endforeach
            </div>
            <hr>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
        </div>
    </form>

    <script type="text/javascript">
        var id = {{ $i }};

        function add() {
            id++;
            var clearinput = '<div class="row" id="links[' + id + ']">' +
                '<div class="col-xs-6 col-sm-5">' +
                '<div class="form-group label-floating is-empty">' +
                '<label for="links[' + id + '][name]" class="control-label">Name</label>' +
                '<input name="links[' + id + '][name]" class="form-control" type="text" value="" required>' +
                '</div>' +
                '</div>' +
                '<div class="col-xs-6 col-sm-5">' +
                '<div class="form-group label-floating is-empty">' +
                '<label for="links[' + id + '][url]" class="control-label">Link</label>' +
                '<input name="links[' + id + '][url]" class="form-control" type="text" value="" required>' +
                '</div>' +
                '</div>' +
                '<div class="col-xs-12 col-sm-2 text-center">' +
                '<button class="btn btn-warning btn-round" type="button" onclick="removeid(' + id + ')">' +
                '<i class="material-icons">delete</i>' +
                '<div class="ripple-container">' +
                '</div>' +
                '</button>' +
                '</div>' +
                '<div class="col-xs-5 form-group" style="padding-bottom: 0px; margin: 0px;">' +
                '<div class="checkbox">' +
                '<label>' +
                '<input type="checkbox" name="links[' + id + '][footer]">' +
                '<span class="checkbox-material">' +
                '<span class="check"></span>' +
                '</span> Show in Footer?</label>' +
                '</div>' +
                '</div>' +
                '<div class="col-xs-7 form-group" style="padding-bottom: 0px; margin: 0px;">' +
                '<div class="checkbox">' +
                '<label>' +
                '<input type="checkbox" name="links[' + id + '][header]">' +
                '<span class="checkbox-material">' +
                '<span class="check">' +
                '</span>' +
                '</span> Show in Header?</label>' +
                '</div>' +
                '</div>' +
                '</div>';
            $('#links').append(clearinput);
            $(`#links\\[${id}\\]`).hide();
            $(`#links\\[${id}\\]`).fadeIn();
        }

        function removeid(blockid) {
            if (blockid == id) {
                id--;
            }
            $(`#links\\[${blockid}\\]`).fadeOut(function () {
                $(this).remove()
            })

        }
    </script>
@endsection
