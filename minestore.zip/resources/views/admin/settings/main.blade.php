@extends('admin.layout')

@section('content')
    <form class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Index</h4>
        </div>
        <div class="card-content">
            <div class="form-group label-floating">
                <textarea id="text" name="index_content" class="form-control">{{ $settings->index_content }}</textarea>
            </div>
            <div class="form-group label-floating">
                <label for="index_deal" class="control-label">Featured Deal</label>
                <select id="index_deal" name="index_deal" class="selectpicker" data-style="select-with-transition" title="Select a featured deal" data-size="7">
                    <option disabled> Select a featured deal</option>
                    @foreach ($items as $item)
                        <option @if($settings->index_deal === $item->id) selected @endif value="{{ $item->id }}">{{ $item->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group label-floating">
                <label for="donation_goal" class="control-label">Donation goal</label>
                <input type="number" id="index_goal" name="index_goal" class="form-control" value="{{ $settings->index_goal }}"
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
        </div>
    </form>
    <script src="//cdn.ckeditor.com/4.6.2/full/ckeditor.js"></script>
    <script type="text/javascript">
        window.onload = function () {
            CKEDITOR.replace('index_content');
        }
    </script>
@endsection
