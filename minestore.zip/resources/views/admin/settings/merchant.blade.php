@extends('admin.layout')

@section('content')
    <form class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">Merchant Settings</h4>
        </div>
        <div class="card-content">
            <div class="nav-center">
                <ul class="nav nav-pills nav-pills-warning" role="tablist">
                    <li class="active"><a href="#paypal" data-toggle="tab">PayPal</a></li>
                    <li><a href="#CoinPayments" data-toggle="tab">CoinPayments</a></li>
                    <li><a href="#G2APay" data-toggle="tab">G2APay</a></li>
                    <li><a href="#2Checkout" data-toggle="tab">2Checkout</a></li>
                </ul>
            </div>
            <div class="tab-content">
                <div class="tab-pane fade in active" id="paypal">
                    <div class="form-group">
                        <div class="togglebutton">
                            <label>
                                <input type="checkbox" name="methods[PayPal][enable]" @if($methods['PayPal']['enable']) checked @endif> Enabled?
                            </label>
                        </div>
                    </div>
                    <div class="text"> Request API access here <a href="https://www.paypal.com/businessprofile/mytools/apiaccess/firstparty">https://www.paypal.com/businessprofile/mytools/apiaccess/firstparty</a> </div>
                    <div class="form-group label-floating">
                        <label for="paypal_user" class="control-label">User API login</label>
                        <input name="methods[PayPal][config][paypal_user]" class="form-control" type="text" value="{{ $methods['PayPal']['config']['paypal_user'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_password" class="control-label">User API password</label>
                        <input name="methods[PayPal][config][paypal_password]" class="form-control" type="text" value="{{ $methods['PayPal']['config']['paypal_password'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_signature" class="control-label">User API signature</label>
                        <input name="methods[PayPal][config][paypal_signature]" class="form-control" type="text" value="{{ $methods['PayPal']['config']['paypal_signature'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_currency_code" class="control-label">Currency code USD\EUR\GBP</label>
                        <input name="methods[PayPal][config][paypal_currency_code]" class="form-control" type="text" value="{{ $methods['PayPal']['config']['paypal_currency_code'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_testing" class="control-label">Sandbox mode (Testing)?</label>
                        <select name="methods[PayPal][config][test]" class="selectpicker" data-style="select-with-transition" title="Sandbox mode (Testing)?" data-size="7" required>
                            <option disabled> Sandbox mode (Testing)?</option>
                            <option value="0" @if(!$methods['PayPal']['config']['test']) selected @endif>Disabled</option>
                            <option value="1" @if($methods['PayPal']['config']['test']) selected @endif>Enabled</option>
                        </select>
                    </div>
                </div>
                <div class="tab-pane fade in" id="CoinPayments">
                    <div class="form-group">
                        <div class="togglebutton">
                            <label>
                                <input type="checkbox" name="methods[CoinPayments][enable]" @if($methods['CoinPayments']['enable']) checked @endif> Enabled?
                            </label>
                        </div>
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_user" class="control-label">Merchant</label>
                        <input name="methods[CoinPayments][config][merchant_coinpayments]" class="form-control" type="text" value="{{ $methods['CoinPayments']['config']['merchant_coinpayments'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_password" class="control-label">Secret</label>
                        <input name="methods[CoinPayments][config][secret_coinpayments]" class="form-control" type="text" value="{{ $methods['CoinPayments']['config']['secret_coinpayments'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_currency_code" class="control-label">Currency code USD\EUR\GBP</label>
                        <input name="methods[CoinPayments][config][currency_code]" class="form-control" type="text" value="{{ $methods['CoinPayments']['config']['currency_code'] }}">
                    </div>
                </div>
                <div class="tab-pane fade in" id="G2APay">
                    <div class="form-group">
                        <div class="togglebutton">
                            <label>
                                <input type="checkbox" name="methods[G2APay][enable]" @if($methods['G2APay']['enable']) checked @endif> Enabled?
                            </label>
                        </div>
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_user" class="control-label">Email</label>
                        <input name="methods[G2APay][config][email]" class="form-control" type="text" value="{{ $methods['G2APay']['config']['email'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_password" class="control-label">Secret</label>
                        <input name="methods[G2APay][config][secret]" class="form-control" type="text" value="{{ $methods['G2APay']['config']['secret'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_currency_code" class="control-label">Hash</label>
                        <input name="methods[G2APay][config][hash]" class="form-control" type="text" value="{{ $methods['G2APay']['config']['hash'] }}">
                    </div>
                </div>
                <div class="tab-pane fade in" id="2Checkout">
                    <div class="form-group">
                        <div class="togglebutton">
                            <label>
                                <input type="checkbox" name="methods[2Checkout][enable]" @if($methods['2Checkout']['enable']) checked @endif> Enabled?
                            </label>
                        </div>
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_user" class="control-label">ID</label>
                        <input name="methods[2Checkout][config][id]" class="form-control" type="text" value="{{ $methods['2Checkout']['config']['id'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_password" class="control-label">Secret</label>
                        <input name="methods[2Checkout][config][secret_word]" class="form-control" type="text" value="{{ $methods['2Checkout']['config']['secret_word'] }}">
                    </div>
                    <div class="form-group label-floating">
                        <label for="paypal_currency_code" class="control-label">Currency code USD\EUR\GBP</label>
                        <input name="methods[2Checkout][config][currency]" class="form-control" type="text" value="{{ $methods['2Checkout']['config']['currency'] }}">
                    </div>
                </div>
				<button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
            </div>
        </div>
    </form>
@endsection
