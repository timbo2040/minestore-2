@extends('admin.layout')

@section('content')
    <form id="rcon" class="card" method="POST">
        <div class="card-header">
            <h4 class="card-title">RCON settings</h4>
        </div>
        <div class="card-content">
            <button class="btn btn-primary btn-block" type="button" onclick="add()"><i class="material-icons">add</i> Add</button>
            <hr>
            <div class="form-group" id="servers">
                @foreach($servers as $server)
                    <?php $i = $server->id ?>
                    <div class="row" id="servers[{{ $i }}]">
                        <div class="col-lg-10">
                            <div class="row">
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][name]" class="control-label">Name</label>
                                        <input name="servers[{{ $i }}][name]" class="form-control" type="text" value="{{ $server->name }}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][host]" class="control-label">Host (IP)</label>
                                        <input name="servers[{{ $i }}][host]" class="form-control" type="text" value="{{ $server->host }}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][port]" class="control-label">Port RCON</label>
                                        <input name="servers[{{ $i }}][port]" class="form-control" type="text" value="{{ $server->port }}" pattern="[0-9]{1,5}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][password]" class="control-label">Password RCON</label>
                                        <input name="servers[{{ $i }}][password]" class="form-control" type="text" value="{{ $server->password }}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][host_websocket]" class="control-label">Host WebSocket (IP)</label>
                                        <input name="servers[{{ $i }}][host_websocket]" class="form-control" type="text" value="{{ $server->host_websocket }}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][port_websocket]" class="control-label">Port WebSocket</label>
                                        <input name="servers[{{ $i }}][port_websocket]" class="form-control" type="text" value="{{ $server->port_websocket }}" pattern="[0-9]{1,5}" required>
                                    </div>
                                </div>
                                <div class="col-xs-6 col-md-3">
                                    <div class="form-group label-floating">
                                        <label for="servers[{{ $i }}][password_websocket]" class="control-label">Password WebSocket</label>
                                        <input name="servers[{{ $i }}][password_websocket]" class="form-control" type="text" value="{{ $server->password_websocket }}" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 text-center">
                            <div class="btn-group">
                                <button class="btn btn-warning btn-round btn-sm" type="button" onclick="removeid('{{ $i }}')"><i class="material-icons">delete</i></button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <hr>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Update</button>
        </div>
    </form>
    <script type="text/javascript">
        <?php
            $id = 0;
            $server = \App\Server::query()->orderBy('id', 'desc')->first();

            if ($server) {
                $id = $server->id;
            }
        ?>
        var id = {{ $id }};
        function add() {
            id++;
            var clearinput = '<div class="row" id="servers[' + id + ']">\n' +
                '                        <div class="col-lg-10">\n' +
                '                            <div class="row">\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][name]" class="control-label">Name</label>\n' +
                '                                        <input name="servers[' + id + '][name]" class="form-control" type="text" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][host]" class="control-label">Host (IP)</label>\n' +
                '                                        <input name="servers[' + id + '][host]" class="form-control" type="text" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][port]" class="control-label">Port RCON</label>\n' +
                '                                        <input name="servers[' + id + '][port]" class="form-control" type="text" pattern="[0-9]{1,5}" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][password]" class="control-label">Password RCON</label>\n' +
                '                                        <input name="servers[' + id + '][password]" class="form-control" type="text" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][host_websocket]" class="control-label">Host WebSocket (IP)</label>\n' +
                '                                        <input name="servers[' + id + '][host_websocket]" class="form-control" type="text" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][port_websocket]" class="control-label">Port WebSocket</label>\n' +
                '                                        <input name="servers[' + id + '][port_websocket]" class="form-control" type="text" pattern="[0-9]{1,5}" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                                <div class="col-xs-6 col-md-3">\n' +
                '                                    <div class="form-group label-floating">\n' +
                '                                        <label for="servers[' + id + '][password_websocket]" class="control-label">Password WebSocket</label>\n' +
                '                                        <input name="servers[' + id + '][password_websocket]" class="form-control" type="text" required>\n' +
                '                                    </div>\n' +
                '                                </div>\n' +
                '                            </div>\n' +
                '                        </div>\n' +
                '                        <div class="col-lg-2 text-center">\n' +
                '                            <div class="btn-group">\n' +
                '                                <button class="btn btn-warning btn-round btn-sm" type="button" onclick="removeid(' + id + ')"><i class="material-icons">delete</i></button>\n' +
                '                            </div>\n' +
                '                        </div>\n' +
                '                    </div>';
            $('#servers').append(clearinput);
            $(`#servers\\[${id}\\]`).hide();
            $(`#servers\\[${id}\\]`).fadeIn();
        }
        function removeid(blockid) {
            if (blockid == id) { id--; }
            $(`#servers\\[${blockid}\\]`).fadeOut(function () {
                $(this).remove()
            })
        }
    </script>
@endsection
