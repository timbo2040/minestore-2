@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="title" class="control-label">Name</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ $category->name }}" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group label-floating">
                <label for="title" class="control-label">Url</label>
                <input type="text" id="url" name="url" class="form-control" value="{{ $category->url }}"
                       aria-required="true">
                <span class="material-input"></span>
                <code>Leave blank if there are subcategories</code>
            </div>
            <div class="form-group label-floating">
                <label for="priority" class="control-label">Priority view</label>
                <input type="number" id="sorting" name="sorting" class="form-control" value="{{ $category->sorting }}">
                <span class="material-input"></span>
            </div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>
@endsection
