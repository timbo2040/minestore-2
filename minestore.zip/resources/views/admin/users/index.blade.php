@extends('admin.layout')

@section('content')
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Users list</h4>
        </div>
        <div class="card-content">
            <a href="{{ route('users_new') }}" class="btn btn-block btn-danger"><i class="material-icons">add</i> Add
                <div class="ripple-container"></div>
            </a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Username</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $user)
                        <tr>
                            <td>{{ $user->id }}</td>
                            <td>{{ $user->username }}</td>
                            <td class="td-actions">
                                <a href="{{ route('users_c', ['id' => $user->id]) }}" rel="tooltip" class="btn btn-info btn-simple"
                                   data-original-title="Edit"><i class="material-icons">edit</i></a>
                                <a href="{{ route('users_delete', ['id' => $user->id])  }}" rel="tooltip"
                                   class="btn btn-danger btn-simple" data-original-title="Delete"><i class="material-icons">close</i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
