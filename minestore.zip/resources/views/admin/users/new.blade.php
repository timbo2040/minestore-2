@extends('admin.layout')

@section('content')
    <form id="category" class="card" method="POST" novalidate="novalidate">
        <div class="card-content">
            <div class="form-group label-floating">
                <label for="title" class="control-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" value="" required=""
                       aria-required="true">
                <span class="material-input"></span>
            </div>
            <div class="form-group">
                <label for="password" class="control-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="HIDDEN" required="yes" aria-required="true">
                <span class="material-input"></span></div>
            <button class="btn btn-block btn-danger"><i class="material-icons">save</i> Save</button>
        </div>
    </form>
@endsection
