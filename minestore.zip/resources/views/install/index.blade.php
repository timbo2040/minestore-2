<!DOCTYPE html>
<html>
<head>
    <title>Script installation...</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="mobile-web-app-capable" content="yes">
    <link href="{{ asset('style/css/bootstrap2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('style/css/material-dashboard.css') }}" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
</head>
<body>
<div class="content">
    <div class="container">
        <div class="text-center">
            <h1 class="title text-primary">Thank you for your purchase!</h1>
        </div>
        <form id="install" autocomplete="off" class="card" method="POST">
            <input id="db_pass" name="db_pass" type="password" autofocus="no" style="display: none;">
            <div class="card-header">
                <h4 class="card-title">Initial setup</h4>
            </div>
            <div class="card-content">
                <div class="form-group label-floating">
                    <label for="site_name" class="control-label">Website name *</label>
                    <input type="text" id="site_name" name="site_name" class="form-control" required>
                </div>
                <div class="form-group label-floating">
                    <label for="serverIP" class="control-label">Server IP *</label>
                    <input type="text" id="serverIP" name="serverIP" class="form-control" required>
                </div>
                <div class="form-group label-floating">
                    <label for="serverPort" class="control-label">Server Port *</label>
                    <input type="text" id="serverPort" name="serverPort" class="form-control" required>
                </div>
                <div class="form-group label-floating">
                    <label for="withdraw_type" class="control-label">Withdraw type *:</label>
                    <select id="withdraw_type" name="withdraw_type" class="selectpicker" data-style="select-with-transition" title="Select delivery method" data-size="7" required>
                        <option disabled>Select delivery method:</option>
                        <option value="rcon">RCON</option>
                        <option value="plugin">Plugin</option>
                    </select>
                </div>
                <div class="form-group label-floating">
                    <label for="withdraw" class="control-label">Withdraw game:</label>
                    <select id="withdraw_game" name="withdraw_game" class="selectpicker" data-style="select-with-transition" title="Select game" data-size="7" required>
                        <option disabled>Select game:
                        <option value="minecraft">Minecraft</option>
                        <option value="unturned">Unturned</option>
                    </select>
                </div>
                <div class="form-group label-floating">
                    <label for="auth" class="control-label">Auth type *:</label>
                    <select id="auth" name="auth" class="selectpicker" data-style="select-with-transition" title="Select auth method" data-size="7" required>
                        <option disabled>Select auth method:</option>
                        <option value="username">Username</option>
                        <option value="steamid">Steam</option>
                    </select>
                </div>
                <div class="form-group label-floating">
                    <label for="webhook_url" class="control-label">WebHook Discord *</label>
                    <input type="text" id="webhook_url" name="webhook_url" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="accessToken" class="control-label">Discord Guild ID *</label>
                    <input type="text" id="discord_guild_id" name="discord_guild_id" class="form-control" placeholder="Discord Guild ID" required>
                </div>
                <div class="form-group">
                    <label for="accessToken" class="control-label">Discord URL *</label>
                    <input type="text" id="discord_url" name="discord_url" class="form-control" placeholder="Discord URL" required>
                </div>
                <h4 class="card-title">Database Connection:</h4>
                <div class="form-group label-floating">
                    <label for="db_host" class="control-label">MySQL Database Host *</label>
                    <input type="text" id="db_host" name="DB_HOST" class="form-control" value="127.0.0.1" required>
                </div>
                <div class="form-group label-floating">
                    <label for="db_port" class="control-label">MySQL Database Port *</label>
                    <input type="text" id="db_port" name="DB_PORT" class="form-control" value="3306" required>
                </div>
                <div class="form-group label-floating">
                    <label for="db_name" class="control-label">MySQL Database Name *</label>
                    <input type="text" id="db_name" name="DB_DATABASE" class="form-control" required>
                </div>
                <div class="form-group label-floating">
                    <label for="db_user" class="control-label">MySQL Database User *</label>
                    <input type="text" id="db_user" name="DB_USERNAME" class="form-control" required>
                </div>
                <div class="form-group label-floating">
                    <label for="db_pass" class="control-label">MySQL Database Password</label>
                    <input type="password" id="db_pass" name="DB_PASSWORD" class="form-control">
                </div>
            </div>
            <div class="card-footer text-center">
                <button type="submit" class="btn btn-info">Install!</button>
            </div>
        </form>
    </div>
</div>
</body>

<script src="{{ asset('style/js/jquery-3.1.1.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/material.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/perfect-scrollbar.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('style/js/jquery.datatables.js') }}"></script>
<script src="{{ asset('style/js/jquery.select-bootstrap.js') }}"></script>
<script src="{{ asset('style/js/jasny-bootstrap.min.js') }}"></script>
<script src="{{ asset('style/js/material-dashboard.js') }}"></script>
<script>
    function setFormValidation(id) {
        $(id).validate({
            errorPlacement: function(error, element) {
                $(element).parent('div').addClass('has-error');
            }
        });
    }

    $(document).ready(function() {
        setFormValidation('#install');
    });
</script>
</html>
