<!DOCTYPE html>
<html>
<head>
    <title>Script installed</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="mobile-web-app-capable" content="yes">
    <link href="{{ asset('style/css/bootstrap2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('style/css/material-dashboard.css') }}" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
          href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
</head>
<body>
<div class="content">
    <div class="container">
        <div class="text-center">
            <h1 class="title text-primary">Thank you for your purchase!</h1>
        </div>
        <div class="card-header">
            <h4 class="card-title">Script installed</h4>
        </div>
        <div class="card-content">
            <span>Admin panel - admin:admin</span>
            <a href="/">Go to site</a>
            <a href="/admin">Go to admin panel</a>
        </div>
    </div>
</div>
</body>

<script src="{{ asset('style/js/jquery-3.1.1.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/material.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/perfect-scrollbar.jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('style/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('style/js/jquery.datatables.js') }}"></script>
<script src="{{ asset('style/js/jquery.select-bootstrap.js') }}"></script>
<script src="{{ asset('style/js/jasny-bootstrap.min.js') }}"></script>
<script src="{{ asset('style/js/material-dashboard.js') }}"></script>
<script>
    function setFormValidation(id) {
        $(id).validate({
            errorPlacement: function (error, element) {
                $(element).parent('div').addClass('has-error');
            }
        });
    }

    $(document).ready(function () {
        setFormValidation('#install');
    });
</script>
</html>
