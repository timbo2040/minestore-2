<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix' => 'categories'], function () {
    Route::post('/get', 'CategoriesController@get');
    Route::post('/get/{url}', 'CategoriesController@getOne');
});

Route::group(['prefix' => '/auth'], function () {
    Route::post('/username', 'AuthController@username');
    Route::get('/steam', 'AuthController@steam');
    Route::get('/steam/handle', 'AuthController@steamHandle');
});

Route::group(['prefix' => 'payments'], function () {
    Route::get('/handle/paypal', 'PaymentController@paypalHandle');
    Route::get('/handle/coinpayments', 'PaymentsController@CoinPaymentsHandle');
    Route::get('/handle/g2a', 'PaymentsController@G2AHandle');
    Route::get('/handle/2checkout', 'PaymentsController@TwoCheckoutHandle');
});

Route::group(['prefix' => 'pages'], function () {
    Route::post('/get', 'PagesController@get');
});

Route::group(['prefix' => 'announcement'], function () {
    Route::post('/get', 'AdvertController@get');
});

Route::group(['prefix' => 'settings'], function () {
    Route::post('/get', 'SettingsController@get');
});

Route::group(['prefix' => 'items'], function () {
    Route::post('/get/guest/{id}', 'ItemsController@getOneGuest');
});

Route::group(['middleware' => 'auth:api'], function () {
    Route::post('/user', function (Request $request) {
        return $request->user();
    });

    Route::group(['prefix' => '/cart'], function () {
        Route::post('/get', 'CartController@get');
        Route::post('/add/{id}', 'CartController@addItem');
        Route::post('/remove/{id}', 'CartController@removeItem');
        Route::post('/reload/{id}', 'CartController@reloadItem');
        Route::post('/acceptCoupon', 'CartController@acceptCoupon');
        Route::post('/getCoupon', 'CartController@getCoupon');
    });

    Route::group(['prefix' => 'payments'], function () {
        Route::post('/get', 'PaymentController@get');
        Route::post('/create', 'PaymentController@create');
    });

    Route::group(['prefix' => 'items'], function () {
        Route::post('/get/{id}', 'ItemsController@getOne');
    });
});
