<?php

use App\Setting;

Route::group(['prefix' => 'admin', 'namespace' => 'Admin', 'middleware' => 'installed'], function () {
    Route::get('/login', 'LoginController@index');
    Route::post('/login', 'LoginController@login');
    Route::get('/logout', 'LoginController@logout');

    Route::group(['middleware' => 'admin'], function () {
        Route::get('/', 'IndexController@index')->name('index');

        Route::group(['prefix' => 'top_categories'], function () {
            Route::get('/', 'TopCategoriesController@index')->name('top_categories');
            Route::get('/new', 'TopCategoriesController@new')->name('top_categories_new');
            Route::post('/new', 'TopCategoriesController@create')->name('top_categories_create');
            Route::get('/c/{id}', 'TopCategoriesController@category')->name('top_categories_c');
            Route::post('/c/{id}', 'TopCategoriesController@edit')->name('top_categories_edit');
            Route::get('/delete/{id}', 'TopCategoriesController@delete')->name('top_categories_delete');
        });

        Route::group(['prefix' => 'categories'], function () {
            Route::get('/', 'CategoriesController@index')->name('categories');
            Route::get('/new', 'CategoriesController@new')->name('categories_new');
            Route::post('/new', 'CategoriesController@create')->name('categories_create');
            Route::get('/c/{id}', 'CategoriesController@category')->name('categories_c');
            Route::post('/c/{id}', 'CategoriesController@edit')->name('categories_edit');
            Route::get('/delete/{id}', 'CategoriesController@delete')->name('categories_delete');
        });

        Route::group(['prefix' => 'goods'], function () {
            Route::get('/', 'GoodsController@index')->name('goods');
            Route::get('/new', 'GoodsController@new')->name('goods_new');
            Route::post('/new', 'GoodsController@create')->name('goods_create');
            Route::get('/c/{id}', 'GoodsController@good')->name('goods_c');
            Route::post('/c/{id}', 'GoodsController@edit')->name('goods_edit');
            Route::get('/delete/{id}', 'GoodsController@delete')->name('goods_delete');
        });

        Route::group(['prefix' => 'coupons'], function () {
            Route::get('/', 'CouponController@index')->name('coupons');
            Route::get('/new', 'CouponController@new')->name('coupons_new');
            Route::post('/new', 'CouponController@create')->name('coupons_create');
            Route::get('/c/{id}', 'CouponController@coupon')->name('coupons_c');
            Route::post('/c/{id}', 'CouponController@edit')->name('coupons_edit');
            Route::get('/delete/{id}', 'CouponController@delete')->name('coupons_delete');
        });

        Route::group(['prefix' => 'gifts'], function () {
            Route::get('/', 'GiftsController@index')->name('gifts');
            Route::get('/new', 'GiftsController@new')->name('gifts_new');
            Route::post('/new', 'GiftsController@create')->name('gifts_create');
            Route::get('/c/{id}', 'GiftsController@coupon')->name('gifts_c');
            Route::post('/c/{id}', 'GiftsController@edit')->name('gifts_edit');
            Route::get('/delete/{id}', 'GiftsController@delete')->name('gifts_delete');
        });

        Route::group(['prefix' => 'pages'], function () {
            Route::get('/', 'PagesController@index')->name('pages');
            Route::get('/new', 'PagesController@new')->name('pages_new');
            Route::post('/new', 'PagesController@create')->name('pages_create');
            Route::get('/c/{id}', 'PagesController@page')->name('pages_c');
            Route::post('/c/{id}', 'PagesController@edit')->name('pages_edit');
            Route::get('/delete/{id}', 'PagesController@delete')->name('pages_delete');
        });

        Route::group(['prefix' => 'payments'], function () {
            Route::get('/', 'PaymentsController@index')->name('payments');
            Route::get('/c/{id}', 'PaymentsController@payment')->name('payments_c');
            Route::get('/delivery/{id}', 'PaymentsController@delivery')->name('payments_delivery');
        });

        Route::group(['prefix' => 'rcon'], function () {
            Route::get('/', 'RconController@index')->name('rcon');
            Route::post('/sendCommand', 'RconController@sendCommand')->name('rcon_sendCommand');
        });

        Route::group(['prefix' => 'users'], function () {
            Route::get('/', 'UsersController@index')->name('users');
            Route::get('/new', 'UsersController@new')->name('users_new');
            Route::post('/new', 'UsersController@create')->name('users_create');
            Route::get('/c/{id}', 'UsersController@user')->name('users_c');
            Route::post('/c/{id}', 'UsersController@edit')->name('users_edit');
            Route::get('/delete/{id}', 'UsersController@delete')->name('users_delete');
        });

        Route::group(['prefix' => 'advert'], function () {
            Route::get('/', 'AdvertController@index')->name('advert');
            Route::post('/', 'AdvertController@save')->name('advert_save');
        });

        Route::group(['prefix' => 'settings'], function () {
            Route::get('/', 'SettingsController@index')->name('settings');
            Route::post('/', 'SettingsController@save')->name('settings_save');
            Route::get('/merchant', 'SettingsController@merchant')->name('settings_merchant');
            Route::post('/merchant', 'SettingsController@merchantSave')->name('settings_merchant_save');
            Route::get('/discord', 'SettingsController@discord')->name('settings_discord');
            Route::post('/discord', 'SettingsController@discordSave')->name('settings_discord_save');
            Route::get('/links', 'SettingsController@links')->name('settings_links');
            Route::post('/links', 'SettingsController@linksSave')->name('settings_links_save');
            Route::get('/servers', 'SettingsController@servers')->name('settings_servers');
            Route::post('/servers', 'SettingsController@serversSave')->name('settings_servers_save');
            Route::get('/main', 'SettingsController@main')->name('settings_main');
            Route::post('/main', 'SettingsController@mainSave')->name('settings_main_save');
        });
    });
});

Route::get('/install', 'InstallController@index');
Route::post('/install', 'InstallController@install');
Route::get('/install/migration', 'InstallController@makeMigration');

Route::get('/{any}', function () {
    $title = \Cache::remember('title', 120, function () {
        $settings = Setting::query()->find(1);

        return $settings->site_name;
    });

    view()->share('mainTitle', $title);

    return view('welcome');
})->where('any', '.*')->middleware('installed');
